// 가격 레벨(price type) 공용 헬퍼
// 데이터 관행:
//  - increaseType='percentage' 의 increaseValue 는 기준가 대비 배수 % (예: 121 = 기준가의 121%)
//  - increaseType='amount' 의 increaseValue 는 기준가에 더하는 고정 금액
//  - increaseValue=0 은 수동 입력 레벨 (자동 계산 없음)
//  - 'PRECIO 1' / 'PRECIO BASE' (increaseValue=0) 는 product.price(precio base) 와 동일 개념
//    → 상품 폼의 Precio base 박스와 중복되므로 동적 레벨 목록에서 제외한다

// base 성격 레벨 여부 (PRECIO 1 / PRECIO BASE + increaseValue=0)
export const isBaseLikePriceType = (pt: any): boolean => {
  const name = String(pt?.name || '').trim();
  const inc = Number(pt?.increaseValue) || 0;

  return inc === 0 && /^precio\s*(1|base)\b/i.test(name);
};

// 상품 폼/목록에 표시할 가격 레벨 필터
// (매장 격리 + 활성 + base 중복 제외 — 수동 레벨(increaseValue=0)은 표시함)
export const filterVisiblePriceTypes = (list: any, storeId?: number): any[] => {
  const arr = Array.isArray(list) ? list : [];

  return arr.filter(
    (pt: any) =>
      pt &&
      pt.storeId === storeId &&
      (pt.status === 1 || pt.status === undefined) &&
      !isBaseLikePriceType(pt)
  );
};

// swr 응답에서 base 성격 레벨을 찾아 이름 반환 (Precio base 박스 라벨용)
export const findBasePriceTypeName = (list: any, storeId?: number): string | null => {
  const arr = Array.isArray(list) ? list : [];
  const found = arr.find(
    (pt: any) =>
      pt &&
      pt.storeId === storeId &&
      (pt.status === 1 || pt.status === undefined) &&
      isBaseLikePriceType(pt)
  );

  return found?.name || null;
};

// 기준가 변경 시 자동 레벨만 다시 계산하고 increaseValue=0 수동 레벨은 보존한다.
export const recalculateDerivedPrices = (basePrice: number, priceTypes: any[], currentPrices: any[]): any[] =>
  priceTypes.map((pt: any) => {
    const existing = currentPrices.find((price: any) => price.priceTypeId === pt.id);
    const increaseValue = Number(pt.increaseValue) || 0;
    if (increaseValue === 0) {
      return existing || { priceTypeId: pt.id, amount: 0, currency: 'ARS' };
    }

    let amount = pt.increaseType === 'amount'
      ? Number(basePrice) + increaseValue
      : Number(basePrice) * (increaseValue / 100);
    if (pt.roundingEnabled) {
      const precision = Number(pt.precision) || 1;
      if (pt.roundingType === 'up') amount = Math.ceil(amount / precision) * precision;
      else if (pt.roundingType === 'down') amount = Math.floor(amount / precision) * precision;
      else amount = Math.round(amount / precision) * precision;
    }

    return { priceTypeId: pt.id, amount: Math.round(amount), currency: existing?.currency || 'ARS' };
  });
