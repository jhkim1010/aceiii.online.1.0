import { useCallback, useEffect, useState } from 'react';
import { Box, Chip, Grid, Typography } from '@mui/material';
import { toast } from 'react-toastify';
import GroupBox from 'src/components/ui/GroupBox';
import FullTable from 'src/components/table/FullTable';
import { columns } from './components/DataConfig';
import apiConnector from 'src/services/api.service';
import { useSaleProducts } from 'src/views/homes/hook/SaleProductsContext';
import { useSuspendedSaleSocket } from 'src/views/homes/hook/useSuspendedSaleSocket';
import { useAuth } from 'src/hooks/useAuth';
import WithFunctionAccess from 'src/configs/withFunctionAccess';

const DraftAndDebtorsList = ({ refresh }: { refresh: boolean }) => {
  const { user } = useAuth();
  const [suspendedSales, setSuspendedSales] = useState<any[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const {
    setSelectedClient, setProducts, setPaymentMethods, setDiscounts,
    setTransport, setNotes, setSuspendedSaleId, setSuspendedSaleDate,
    setSuspendedSellerName, setSuspendedClientName, setSuspendedNumPedido,
    setSuspendedItemCount, setSuspendedTotalAmount,
    setSelectedSeller, setSalesProvinceId, products, suspendedSaleId,
  } = useSaleProducts();

  // silent=true 면 로딩/에러 UI 를 건드리지 않고 조용히 목록만 갱신 (폴링용 — 깜빡임 방지)
  const getSuspendedSales = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    if (!silent) setError(null);

    try {
      const response: any = await apiConnector.get('/suspended-sales');
      const data = Array.isArray(response.data) ? response.data : (Array.isArray(response) ? response : []);
      setSuspendedSales(data);
      setTotal(data.length);
    } catch (err: any) {
      if (!silent) setError(err.message || 'Error al cargar ventas suspendidas');
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    getSuspendedSales();
  }, [getSuspendedSales, refresh]);

  // 1차: Socket.io 즉시 푸시 — WP webhook / 모바일 판매원(Phase 37) 등으로 보류판매가
  // 생성/취소되면 서버가 'suspended-sale:changed' 를 매장 전체에 emit → 폴링 대기 없이 즉시 재조회.
  //
  // UI-D4: 모바일에서 새 보류판매(action:'new')가 도착하면 데스크탑 운영자에게 prominent 토스트로
  // 도착을 알린다 (feedback_error_visibility — 전면 노출). 취소(action:'cancel')는 조용히 갱신만.
  useSuspendedSaleSocket(user?.id, user?.storeId, (payload) => {
    if (payload?.action === 'new') {
      const suffix = payload.numPedido ? ` #${payload.numPedido}` : '';
      toast.info(`Nueva venta en espera desde el móvil${suffix}`, {
        autoClose: 6000,
      });
    }

    getSuspendedSales(true);
  });

  // 2차(fallback): 60초 조용한 폴링 — 소켓 끊김/emit 유실 시 회복용 안전망.
  useEffect(() => {
    const t = setInterval(() => getSuspendedSales(true), 60000);

    return () => clearInterval(t);
  }, [getSuspendedSales]);

  const handleDelete = async (row: any) => {
    const confirmed = window.confirm(
      `\u00bfEliminar definitivamente la venta suspendida #${row.id}?`,
    );
    if (!confirmed) return;

    try {
      await apiConnector.remove(`/suspended-sales/${row.id}`);
      setSuspendedSales(prev => prev.filter(s => s.id !== row.id));
      setTotal(prev => Math.max(0, prev - 1));
      if (suspendedSaleId === row.id) setSuspendedSaleId(null);
      toast.success('Venta suspendida eliminada');
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'No se pudo eliminar la venta suspendida');
    }
  };

  const cols = columns(handleDelete);

  // 일시 중단 판매 클릭 시 DB 행은 유지하고 왼쪽 패널에 비파괴 복원한다.
  const handleRowClick = async (params: any) => {
    const row = params.row;

    // 다른 카트/보류판매를 편집 중이면 덮어쓰기 전에 확인한다.
    if (products.length > 0 && suspendedSaleId !== row.id) {
      const confirmed = window.confirm(
        '\u00bfReemplazar la venta actual? Los cambios no guardados se perder\u00e1n.',
      );
      if (!confirmed) return;
    }

    // 메타데이터와 ID 보존 — 재보류 시 같은 행을 PUT 갱신한다.
    setSuspendedSaleId(row.id);
    setSuspendedSaleDate(row.createdAt || row.saleDate || null);
    setSuspendedSellerName(row.user?.name || row.seller?.name || null);
    setSuspendedClientName(row.client?.fullname || 'Consumidor Final');
    setSuspendedNumPedido(row.numPedido || null);
    const itemCount = (row.items || row.suspendedSaleItems || [])
      .reduce((sum: number, item: any) => sum + (Number(item.quantity) || 0), 0);
    setSuspendedItemCount(itemCount);
    setSuspendedTotalAmount(Number(row.totalAmount) || 0);

    // 왼쪽 패널에 데이터 복원
    setSelectedClient(row.client || null);

    // item.product (백엔드 응답 include) 로부터 실제 이름/sku 를 사용
    // variantQuantities 가 있으면 isParent=true 복원 (cart 행 1개 = parent 1개 — 원 구조 유지)
    //
    // [VARIATION-BUG fix] suspender→restore 시 sizes/colors/stockByVariant 가 누락되어
    // venta 확정 흐름이 fallback(parent 단일 item)으로 빠지는 문제 수정.
    // restore 시점에 by-parent API 한 번 호출해서 parent 상품의 variant 메타를 합친다.
    const rawItems = (row.items || row.suspendedSaleItems || []) as any[];
    const hasParentItems = rawItems.some(
      (it: any) =>
        !!it.variantQuantities &&
        Object.keys(it.variantQuantities || {}).length > 0,
    );

    const parentMetaById: Record<number, any> = {};
    if (hasParentItems) {
      try {
        // 매장 + 지점의 parent 상품 목록 (sizes/colors/stockByVariant 포함)
        // 응답 구조: { count: number, data: ProductOption[] }
        // pageSize 를 충분히 크게 — 매장 codigoMadre 전체 한 번에 조회
        const branchId =
          (row as any).branchId ||
          (row.client as any)?.branchId ||
          undefined;
        const branchParam = branchId ? `&branchId=${branchId}` : '';
        const url = `/products/by-parent?parent=true&pageSize=1000${branchParam}`;
        const resp: any = await apiConnector.get(url);

        // 응답 구조 처리: { count, data } | array | { data: { data, count } }
        const list: any[] = Array.isArray(resp)
          ? resp
          : Array.isArray(resp?.data)
            ? resp.data
            : Array.isArray(resp?.data?.data)
              ? resp.data.data
              : [];
        for (const p of list) {
          if (p?.id != null) parentMetaById[p.id] = p;
        }
      } catch (err) {
        console.warn('[Suspended] by-parent 조회 실패 — fallback 진행:', err);
      }
    }

    const restoredProducts = rawItems.map((item: any) => {
      const hasVariants =
        !!item.variantQuantities &&
        Object.keys(item.variantQuantities || {}).length > 0;
      const meta = hasVariants ? parentMetaById[item.productId] : null;

      return {
        id: item.productId,
        productId: item.productId,
        name:
          item.product?.name ||
          item.customName ||
          `Producto ${item.productId}`,
        sku: item.product?.sku || '',
        quantity: Number(item.quantity) || 0,
        price: Number(item.price),
        customName: item.customName || null,
        isParent: hasVariants,
        variantQuantities: hasVariants ? item.variantQuantities : undefined,

        // variant 메타 동봉 — venta 확정 시 expandedItems 가 정상 분해되도록
        sizes: meta?.sizes || [],
        colors: meta?.colors || [],
        stockByVariant: meta?.stockByVariant || [],
      };
    });

    setProducts(restoredProducts);
    setPaymentMethods([]);
    setDiscounts(
      (row.suspendedDiscounts || []).map((d: any) => ({
        name: d.name,
        amountDiscount: d.amountDiscount,
      }))
    );
    setTransport(row.transport || 0);
    setNotes(row.notes || '');

    // vendedor + provincia 복원 (Phase 26 Wave 5)
    if (row.seller || row.sellerId) {
      const seller = row.seller || { id: row.sellerId, name: row.sellerName };
      setSelectedSeller(seller);
    } else {
      setSelectedSeller(null);
    }
    setSalesProvinceId(row.provinceId || null);
  };

  return (
    <WithFunctionAccess functionSlug="ver-facturas-con-deudas">
      <GroupBox title={`Ventas Suspendidas (${total})`} sx={{ backgroundColor: 'white', marginBottom: 8, height: '100%', display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ flex: 1, minHeight: 0, overflow: 'auto' }}>
          {/* UI-D4: 대기 중 보류판매 건수 배지 — 모바일 도착분 포함 */}
          <Box sx={{ mb: 1 }}>
            <Chip
              label={`${total} en espera`}
              color={total > 0 ? 'primary' : 'default'}
              size="small"
            />
          </Box>
          <Grid container spacing={1}>
            <Grid item xs={12} sx={{ mx: 0, px: 0 }}>
              {loading ? (
                <Typography>Cargando...</Typography>
              ) : error ? (
                <Typography color="error">{error}</Typography>
              ) : (
                <FullTable
                  data={{
                    data: suspendedSales,
                    count: total
                  }}
                  columns={cols}
                  paginationModel={paginationModel}
                  setPagination={setPaginationModel}
                  onRowClick={handleRowClick}
                  checkboxSelection={false}
                />
              )}
            </Grid>
          </Grid>
        </Box>
      </GroupBox>
    </WithFunctionAccess>
  );
};

export default DraftAndDebtorsList;
