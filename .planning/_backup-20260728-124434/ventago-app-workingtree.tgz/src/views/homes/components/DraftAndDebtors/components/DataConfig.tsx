import { GridColDef } from 'src/components/table/grid-types';
import { titleColumn } from 'src/components/table/columns';
import * as yup from 'yup';
import { IconButton, Tooltip } from '@mui/material';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';

export const columns = (onDelete?: (row: any) => void): GridColDef[] => {
  return [
    {
      flex: 0.08,
      minWidth: 50,
      field: 'itemCount',
      headerName: 'Prendas',
      sortable: true,
      valueGetter: (params: any) => {
        const items = params.row?.items || params.row?.suspendedSaleItems || [];

        return items.reduce((sum: number, item: any) => sum + (Number(item.quantity) || 0), 0);
      },
      renderCell: (params: any) => titleColumn(params.value || 0),
    },
    {
      flex: 0.12,
      minWidth: 80,
      field: 'totalAmount',
      headerName: 'Total',
      sortable: true,
      renderCell: (params: any) => {
        const val = Number(params.value) || 0;

        return titleColumn(`$${val.toLocaleString()}`);
      },
    },
    {
      flex: 0.18,
      minWidth: 100,
      field: 'client',
      headerName: 'Cliente',
      sortable: true,
      valueGetter: (params: any) => params.row?.client?.fullname || 'Consumidor Final',
      renderCell: (params: any) => titleColumn(params.value),
    },
    {
      flex: 0.14,
      minWidth: 90,
      field: 'sellerName',
      headerName: 'Vendedor',
      sortable: true,
      valueGetter: (params: any) => {
        // WP webhook 출처 보류판매 → 판매원 "Web (WP)" (user/seller 없음)
        if (params.row?.source === 'wp') return 'Web (WP)';

        return params.row?.user?.name || params.row?.seller?.name || '-';
      },
      renderCell: (params: any) =>
        params.row?.source === 'wp'
          ? titleColumn(`🌐 ${params.value}`, 'info.main')
          : titleColumn(params.value),
    },
    {
      flex: 0.06,
      minWidth: 40,
      field: 'id',
      headerName: 'ID',
      sortable: true,
      renderCell: (params: any) => titleColumn(params.value),
    },
    {
      flex: 0.14,
      minWidth: 85,
      field: 'fecha',
      headerName: 'Fecha',
      sortable: true,
      valueGetter: (params: any) => {
        const d = params.row?.createdAt;
        if (!d) return '-';

        return new Date(d).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
      },
      renderCell: (params: any) => titleColumn(params.value),
    },
    {
      flex: 0.08,
      minWidth: 60,
      field: 'hora',
      headerName: 'Hora',
      sortable: true,
      valueGetter: (params: any) => {
        const d = params.row?.createdAt;
        if (!d) return '-';

        return new Date(d).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
      },
      renderCell: (params: any) => titleColumn(params.value),
    },
    {
      flex: 0.1,
      minWidth: 70,
      field: 'numPedido',
      headerName: 'Pedido',
      sortable: true,
      renderCell: (params: any) => titleColumn(params.value || '-'),
    },
    {
      flex: 0.06,
      minWidth: 55,
      field: 'actions',
      headerName: '',
      sortable: false,
      renderCell: (params: any) => (
        <Tooltip title="Eliminar venta suspendida">
          <IconButton
            size="small"
            color="error"
            aria-label={`Eliminar venta suspendida ${params.row?.id}`}
            onClick={(event) => {
              event.stopPropagation();
              onDelete?.(params.row);
            }}
          >
            <DeleteOutlineIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      ),
    },
  ];
};

export const schema = yup.object().shape({
  name: yup.string().required('Code is required'),
  slug: yup.string(),
});

export const defaultValues = {
  name: '',
  description: '',
  slug: '',
};
