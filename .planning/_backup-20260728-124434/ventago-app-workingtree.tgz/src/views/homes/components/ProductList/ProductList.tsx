import { useContext, useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useRouter } from "next/router";
import dynamic from "next/dynamic";
import GroupBox from "src/components/ui/GroupBox";
import ProductInputs from "./components/ProductsInputs";
import ProductListTable from "./components/ProductListTable";
import PaymentSummary from "./components/PaymentSummary";
import PromoBannerStack from "./components/PromoBannerStack";
import { Button, Box, Typography, Grid, Tooltip, FormControlLabel, Checkbox, MenuItem, Dialog, DialogTitle, DialogContent, DialogActions, TextField } from "@mui/material";
import CustomTextField from "src/@core/components/mui/text-field";
import apiConnector from "src/services/api.service";
import { useSaleProducts } from "src/views/homes/hook/SaleProductsContext";
import { useThermalAgentStatus } from "src/views/homes/hook/useThermalAgentStatus";
import { warnPrintFallbackOnce } from "src/services/print.service";
import { fetchLiveStock, mergeLiveStock } from "src/views/homes/utils/liveStock";
import { useAuth } from "src/hooks/useAuth";
import { BranchContext } from "src/context/BranchContext";
import { toast } from "react-toastify";
import { Icon } from "@iconify/react";
import { useHotkeys } from 'react-hotkeys-hook';

// PaymentMethodsModal은 InvoiceAditional에서 직접 관리
import WithFunctionAccess from "src/configs/withFunctionAccess";
import InvoiceAditional from "./components/InvoiceAditional";
import { getBusinessDateAsDate } from "src/services/businessDate.service";

// Task 7 — POS Facturar 편의 버튼(AFIP Factura Electrónica, FE 활성+수동 발급 매장만 게이트)
import { useStoreConfig } from "src/context/StoreConfigContext";
import { useAfipIssuers } from "src/hooks/api/useAfipIssuers";

// Phase 58+ — 오프라인 시 AFIP 발급(F10) 차단용 상태 훅
import { useOfflineStatus } from "src/hooks/useOfflineStatus";

// 300ms POS 성능 예산 — FE 미사용 매장 번들에서 제외 (afipService 등 전이 의존성 lazy-load)
const PartialInvoiceModal = dynamic(() => import("src/views/facturacion/PartialInvoiceModal"), { ssr: false });

// ─── autoImpTiq 영수증용 variant 매트릭스 재구성 ──────────────────────────────
// parent(코드마드레) 장바구니 행을 print-agent formatter 가 기대하는
//   { colors: string[], sizes: string[], matrix: { [color]: { [size]: number } } }
// 형태로 변환. 백엔드 groupItemsForPrint(print-invoice-items.ts) 와 동일한 결과를
// 만들어, autoImpTiq 자동출력 경로에서도 변형표가 영수증에 찍히도록 한다.
// variant 정보가 없으면 undefined → formatter 는 일반 단일 행으로 출력.
const buildPrintVariants = (
  p: any,
):
  | { colors: string[]; sizes: string[]; matrix: Record<string, Record<string, number>> }
  | undefined => {
  const vq = p?.variantQuantities;
  const sbv = Array.isArray(p?.stockByVariant) ? p.stockByVariant : [];
  if (p?.isParent !== true || !vq || Object.keys(vq).length === 0 || sbv.length === 0) {
    return undefined;
  }

  const matrix: Record<string, Record<string, number>> = {};
  const colorOrder: string[] = [];
  const sizeSort = new Map<string, number | null>();

  // variantQuantities 키 = "colorId-sizeId" → stockByVariant 로 이름 해석 후 매트릭스 누적
  Object.entries(vq).forEach(([key, rawQty]) => {
    const qty = Number(rawQty);
    if (!qty || qty <= 0) return;

    const [colorIdStr, sizeIdStr] = String(key).split('-');
    const colorId = Number(colorIdStr);
    const sizeId = Number(sizeIdStr);
    const v = sbv.find((s: any) => s?.color?.id === colorId && s?.size?.id === sizeId);
    const colorName = v?.color?.name ?? '—';
    const sizeName = v?.size?.name ?? '—';

    matrix[colorName] = matrix[colorName] ?? {};
    matrix[colorName][sizeName] = (matrix[colorName][sizeName] ?? 0) + qty;
    if (!colorOrder.includes(colorName)) colorOrder.push(colorName);
    if (!sizeSort.has(sizeName)) sizeSort.set(sizeName, v?.size?.sortOrder ?? null);
  });

  if (Object.keys(matrix).length === 0) return undefined;

  // 백엔드 print-invoice-items.ts 와 동일 정렬: color 자연순, size 는 sortOrder 우선
  const colors = colorOrder
    .slice()
    .sort((a, b) => a.localeCompare(b, 'es-AR', { numeric: true }));
  const sizes = Array.from(sizeSort.entries())
    .sort((a, b) => {
      const oa = a[1];
      const ob = b[1];
      if (oa !== null && ob !== null) return oa - ob;
      if (oa !== null) return -1;
      if (ob !== null) return 1;

      return a[0].localeCompare(b[0], 'es-AR', { numeric: true });
    })
    .map(([name]) => name);

  return { colors, sizes, matrix };
};

const ProductList = (props: any) => {
  const { user } = useAuth();
  const { selectedBranchId } = useContext(BranchContext);
  const router = useRouter();

  // promoResult: Phase A 프로모션 — 카트 평가 결과 (Task 20 에서 노출). Sale POST 시 promo metadata 주입에 사용.
  const { products, setProducts, addProduct, clearProducts, selectedClient, setSelectedClient, setSizes, setColors, setStockByVariant, setRestoredQuantities, activeParentId, setActiveParentId, setActiveProductImages, discounts, recharges, transport, paymentMethods, resetSale, selectedSeller, suspendedNumPedido, suspendedSaleId, salesProvinceId, clientFormData, promoResult } = useSaleProducts();
  const [printTicket] = useState(false);

  // Phase 64 W1 — 판매 생성 멱등키.
  // 한 번의 "확정" 시도에 키 1개를 붙이고, 성공할 때까지 같은 키를 유지한다.
  // 네트워크 오류로 재시도해도 서버가 같은 키를 알아보고 판매를 복제하지 않는다.
  const idempotencyKeyRef = useRef<string | null>(null)

  // Task 7 — POS Facturar 편의 버튼. FE 비활성/자동발급 매장은 gate=false → 훅 이하 전부 비활성/미노출.
  const { useFacturaElectronica, afipAutoIssue, afipDefaultPct } = useStoreConfig();
  const facturarGateOn = useFacturaElectronica && !afipAutoIssue;

  // F10 발급 플로우: FE 활성 매장이면 PV(issuers) 필요 (afipAutoIssue 무관)
  const feOn = useFacturaElectronica;
  const { data: afipIssuers } = useAfipIssuers(feOn);
  const defaultPv = afipIssuers?.[0]?.puntoVenta;

  // 오프라인 게이팅: 인터넷 단절 중에는 AFIP 실시간 발급(F10)을 차단한다.
  // (오프라인에선 CAE 발급 불가 — 판매는 F2 로 완료하고 발급은 복구 후 처리)
  const { isOffline } = useOfflineStatus();
  const [lastSale, setLastSale] = useState<any | null>(null);
  const [facturarSale, setFacturarSale] = useState<any | null>(null);

  // CodigosMadres 체크박스 초기값:
  //   - 매장이 color 또는 talle 를 사용하면 (variants 모드) → 기본 active (true)
  //   - 둘 다 사용 안 하면 (단순 모드) → 기본 false (코드 madre/hijito 구분 없음)
  // store-config 가 로드될 때까지는 true 로 유지 (variants 사용이 일반적인 default).
  const [showParentsState, setShowParentsState] = useState(true);
  useEffect(() => {
    if (!user?.storeId) return;
    apiConnector
      .get(`/store-config/${user.storeId}`)
      .then((res: any) => {
        const usesVariants = !!(res?.useColor || res?.useSize);
        setShowParentsState(usesVariants);
      })
      .catch(() => {
        // 네트워크 오류 시 기본 true 유지 — variants 모드가 일반적
      });
  }, [user?.storeId]);

  const [rawProducts, setRawProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 판매 완료 후 재고 매트릭스를 최신 stocks 값으로 다시 불러오기 위한 트리거
  const [refreshProducts, setRefreshProducts] = useState(0);

  // openPaymentModal은 InvoiceAditional에서 관리
  const [qMode, setQMode] = useState(true);
  const [movidosMode, setMovidosMode] = useState(false);
  const [falladosMode, setFalladosMode] = useState(false);
  const [originBranchId, setOriginBranchId] = useState<string>('');
  const [targetBranchId, setTargetBranchId] = useState<string>('');
  const [branches, setBranches] = useState<any[]>([]);
  const [cashRegister, setCashRegister] = useState<any | null>(null);
  const [refreshCashRegister, setRefreshCashRegister] = useState(0);

  // auto impTiq — Generar Venta 성공 후 자동으로 print-agent 로 티켓 출력 여부.
  // localStorage 로 세션 간 유지.
  const [autoImpTiq, setAutoImpTiq] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;

    return window.localStorage.getItem('ventago.autoImpTiq') === '1';
  });
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('ventago.autoImpTiq', autoImpTiq ? '1' : '0');
    }
  }, [autoImpTiq]);

  const totalPrendas = products.reduce((acc: number, p: any) => acc + (p.quantity ?? 0), 0);
  const subtotal = products.reduce((acc: number, p: any) => acc + (p.price * p.quantity), 0);
  const totalPagos = paymentMethods && paymentMethods.length > 0 ? paymentMethods.reduce((acc: number, p: any) => acc + (p.amount || 0), 0) : 0;

  // paymentModalFormRef 제거 (모달은 InvoiceAditional에서 관리)
  const [editingProduct, setEditingProduct] = useState<any | null>(null);
  const totalDiscounts = discounts.reduce((acc: number, d: any) => acc + (d.amountDiscount || 0), 0);
  const totalRecharges = recharges?.reduce((acc: number, r: any) => acc + (r.amountRecharge || 0), 0) || 0;

  // Phase A 프로모션: 'Descuento x promoción' 으로 SaleProductsContext 가 자동 등록 → totalDiscounts 에 포함됨.
  // 별도 차감 없이 totalDiscounts 만으로 일관 처리.
  const totalFactura = subtotal - totalDiscounts + totalRecharges + (transport || 0);
  const isValidPayment = totalPagos === totalFactura && totalFactura > 0;
  const disabledReason = !isValidPayment ? 'payment_invalid' : !cashRegister?.terminal?.name ? 'no_terminal' : !cashRegister?.box?.name ? 'no_box' : 'ENABLED';
  console.log('[GenerarVenta]', { disabledReason, isValidPayment, totalPagos, totalFactura, paymentMethods: paymentMethods?.length, cashTerminal: cashRegister?.terminal?.name, cashBox: cashRegister?.box?.name });


  // 현재 판매 지점 — POS 는 그 지점의 stock 만 보여줘야 함 (다른 지점 재고 합산 시 over-sell 위험)
  const saleBranchId = (user as any)?.branchId ?? cashRegister?.box?.branchId ?? null;

  useEffect(() => {
    setLoading(true);
    const branchParam = saleBranchId ? `&branchId=${saleBranchId}` : '';

    // pageSize 미지정 시 백엔드 기본값(10)만 내려와 카탈로그가 잘림 → POS 검색이 최신 10건에서만 매칭.
    // 검색은 클라이언트(ProductsInputs filterOptions)에서 하므로 전체 목록이 필요.
    // 형제 호출부(DraftAndDebtorsList=1000, 레스토랑/온라인=200)와 동일하게 pageSize 명시.
    apiConnector
      .get(`/products/by-parent?parent=${!showParentsState}&pageSize=1000${branchParam}`)
      .then((res: any) => {
        setRawProducts(res.data ?? res);
      })
      .catch(() => {
        setError("Error al cargar productos");
      })
      .finally(() => setLoading(false));
  }, [showParentsState, saleBranchId, refreshProducts]);

  useEffect(() => {
    const handler = () => setRefreshCashRegister(r => r + 1);
    window.addEventListener('cashRegisterUpdated', handler);

    return () => {
      window.removeEventListener('cashRegisterUpdated', handler);
    };
  }, []);

  // 판매 완료(saleCreated) 시 재고 매트릭스를 다시 조회해 stale 스냅샷 방지
  useEffect(() => {
    const handler = () => setRefreshProducts(r => r + 1);
    window.addEventListener('saleCreated', handler);

    return () => {
      window.removeEventListener('saleCreated', handler);
    };
  }, []);

  useEffect(() => {
    let cancelled = false

    const fetchOrAutoOpen = async () => {
      try {
        // [VentaVista fix 2026-07-06] 선택 지점(selectedBranchId)의 caja 만 조회.
        // 무필터 조회는 다지점에서 caja 2개 오픈 시 항상 먼저 연 caja(다른 지점)를 반환해
        // 판매의 terminal/branch 귀속이 첫 지점으로 오염되던 버그의 근원.
        const branchQuery = selectedBranchId ? { branchId: selectedBranchId } : undefined
        const res: any = await apiConnector.get('/cash-register/open', branchQuery)
        if (cancelled) return

        // 이 지점에 열린 caja 가 없으면 (null/undefined) 선택 지점으로 자동 오픈 시도
        if (!res || !res.id) {
          console.log('[CashRegister][VentasDebug] 열린 caja 없음 (branchId =', selectedBranchId, ') → 자동 오픈 시도')
          try {
            const opened: any = await apiConnector.post('/cash-register/auto-open', branchQuery ?? {})
            if (!cancelled) {
              console.log('[CashRegister][VentasDebug] 자동 오픈 성공:', opened?.id, 'boxBranchId =', opened?.box?.branchId)
              setCashRegister(opened ?? null)
            }
          } catch (autoErr: any) {
            console.warn('[CashRegister] 자동 오픈 실패:', autoErr?.response?.data?.message || autoErr)
            if (!cancelled) setCashRegister(null)
          }

          return
        }
        console.log('[CashRegister][VentasDebug] 열린 caja:', res?.id, 'boxBranchId =', res?.box?.branchId, '(selectedBranchId =', selectedBranchId, ')')
        setCashRegister(res)
      } catch {
        if (!cancelled) setCashRegister(null)
      }
    }

    fetchOrAutoOpen()

    return () => {
      cancelled = true
    }
  }, [user, refreshCashRegister, selectedBranchId]);

  // branchId 해석 단일화 — 체크박스 상태 조회와 실제 출력 요청이 반드시 같은
  // 지점을 보도록 우선순위를 통일 (box 소속 지점 우선, user 지점은 fallback)
  const currentBranchId =
    cashRegister?.box?.branchId ||
    cashRegister?.box?.branch?.id ||
    (user as any)?.branchId ||
    (user as any)?.sucursalId ||
    null;

  // 연결된 thermal (comandera) print-agent 상태 — autoImpTiq + 상태 pill 제어용.
  // 30초 폴링 제거: /realtime socket push (agent_status_changed) 로 실시간 갱신.
  const { agents: thermalAgents, hasOnlineThermalAgent, refetch: fetchThermalAgents } =
    useThermalAgentStatus(currentBranchId);

  // 이 터미널에 매핑된 comandera — 상태 pill 표시용 (매핑 없으면 fallback broadcast)
  const mappedThermalAgent = useMemo(() => {
    const mappedId = cashRegister?.terminal?.thermalAgentId ?? null;
    if (!mappedId) return null;

    return thermalAgents.find((a) => a.id === mappedId && a.agentType === 'thermal') ?? null;
  }, [cashRegister?.terminal?.thermalAgentId, thermalAgents]);

  // print-agent(comandera) 연결 상태에 autoImpTiq 자동 동기화:
  //   온라인 thermal 에이전트가 연결되면 자동 체크(ON), 없으면 자동 해제(OFF).
  //   에이전트 상태(hasOnlineThermalAgent)가 바뀔 때만 실행되므로,
  //   사용자가 온라인 중 수동으로 끈 경우엔 값이 불변이라 재실행되지 않아 꺼진 상태가 유지된다.
  useEffect(() => {
    setAutoImpTiq(hasOnlineThermalAgent);
  }, [hasOnlineThermalAgent]);

  // 체크박스 토글 가드: 켜려는 시점에 fresh fetch 후 결과로 결정
  const handleAutoImpTiqChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const next = e.target.checked;
    if (!next) {
      setAutoImpTiq(false);

      return;
    }

    // 켜려고 시도: stale 가능성 회피하려고 fresh fetch
    const list = await fetchThermalAgents();
    const online = list.some((a: any) => a.agentType === 'thermal' && a.isOnline === true);
    if (!online) {
      toast.warning('No hay una comandera (print-agent) conectada. No se puede activar auto impTiq.');

      return;
    }
    setAutoImpTiq(true);
  };

  // Sucursales 목록 로드 + 유저 branchId를 Origen 기본값으로
  useEffect(() => {
    apiConnector.get('/branch')
      .then((res: any) => {
        const list = res.data || res || [];
        setBranches(list);
        const userBranch = (user as any)?.branchId || (user as any)?.cashRegister?.branchId;
        if (userBranch) setOriginBranchId(String(userBranch));
      })
      .catch(() => setBranches([]));
  }, [user]);

  const productOptions: any[] = rawProducts?.map((product: any) => {
    const parsedPrice = parseFloat(product.price);

    // [PRECIO-BASE 디버그] 백엔드(findByParentFlag)가 price 컬럼을 안 실어보내면 NaN → POS 폴백 0원.
    // 정상 응답이면 절대 안 찍힘. 다시 찍히면 백엔드 응답 DTO 에서 price 누락된 것.
    if (Number.isNaN(parsedPrice)) {
      console.warn('[PRECIO-BASE] product.price NaN — 백엔드 응답에 price 누락:', {
        id: product?.id,
        sku: product?.sku,
        rawPrice: product?.price,
      });
    }

    return {
      ...product,
      price: parsedPrice,
    };
  });

  // Fix C: suspender→recall 시 누락된 stockByVariant/sizes/colors 를 rawProducts(서버 fetch)에서 자동 보강
  // - cart 안의 parent 상품 중 stockByVariant 가 없는 것을 찾아 매칭되는 rawProducts 데이터로 채움
  // - displayProducts 펼치기 로직이 색상/사이즈 이름까지 정확하게 표시할 수 있게 함
  // [VARIATION-BUG fix] 의존성에 products.length 도 포함 — restore 직후(rawProducts 이미 로드된 상태)
  // setProducts 호출 시에도 augment 트리거. 무한루프 방지: needsAugment 가드 + 새 객체 반환 시에만 setProducts.
  useEffect(() => {
    if (!Array.isArray(rawProducts) || rawProducts.length === 0) return;
    if (!Array.isArray(products) || products.length === 0) return;

    // showParentsState 와 무관하게 augment 시도 — rawProducts 가 hijitos 만 있으면 매칭 실패해 그대로 유지
    const needsAugment = products.some(
      (p: any) =>
        p?.isParent === true &&
        (!Array.isArray(p?.stockByVariant) || p.stockByVariant.length === 0),
    );
    if (!needsAugment) return;

    let changed = false;
    const augmented = products.map((p: any) => {
      if (
        p?.isParent !== true ||
        (Array.isArray(p?.stockByVariant) && p.stockByVariant.length > 0)
      ) {
        return p;
      }
      const opt = rawProducts.find((o: any) => o.id === (p.productId || p.id));
      if (!opt?.stockByVariant || opt.stockByVariant.length === 0) return p;
      changed = true;

      return {
        ...p,
        stockByVariant: opt.stockByVariant,
        sizes: opt.sizes,
        colors: opt.colors,
      };
    });

    if (changed) {
      // suspender→restore 흐름에서 stockByVariant 가 누락된 경우 rawProducts 로 보강
      setProducts(augmented);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rawProducts, products.length]);

  // 제품을 읽거나(스캔/추가) 선택하면 즉시 그 제품 사진을 ImgProducts 에 반영.
  // activeParentId 는 addProduct(스캔/추가) 와 행 클릭 모두에서 설정되므로 단일 진입점.
  useEffect(() => {
    if (activeParentId == null) {
      setActiveProductImages([]);

      return;
    }
    const opt = rawProducts.find((o: any) => o.id === activeParentId);
    const imgs: string[] = Array.isArray(opt?.imageUrls) && opt.imageUrls.length
      ? opt.imageUrls
      : (opt?.imageUrl ? [opt.imageUrl] : []);
    setActiveProductImages(imgs);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeParentId, rawProducts]);

  // Fallados/Movidos 모드: 가격 0으로 제품 추가
  const isSpecialMode = falladosMode || movidosMode;

  const handleAddProduct = (product: any) => {
    if (isSpecialMode) {
      addProduct({ ...product, price: 0 });
    } else {
      addProduct(product);
    }
  };

  // Fallados/Movidos 전용 등록 처리 (판매가 아닌 재고 이동)
  const handleSubmitSpecial = async () => {
    if (products.length === 0) {
      toast.warning("Agrega al menos un producto.");

      return;
    }

    // Phase 35 — multi-branch admin (user.branchId NULL) 대응 fallback.
    // setState 는 비동기라 같은 사이클에서 originBranchId 변수는 갱신 안 됨 → resolved 로컬 사용.
    // 우선순위: 명시 originBranchId → 사이드바 selectedBranchId → user.cashRegister.branchId → 첫 branch.
    const resolvedOriginBranchId =
      originBranchId ||
      (selectedBranchId ? String(selectedBranchId) : '') ||
      ((user as any)?.cashRegister?.branchId ? String((user as any).cashRegister.branchId) : '') ||
      (branches[0]?.id ? String(branches[0].id) : '');
    if (!resolvedOriginBranchId) {
      toast.error("Origen 지점이 설정되지 않았습니다. 사이드바에서 지점을 선택하거나 caja를 열어 주세요.");

      return;
    }


    // UI state 동기화 (다음 렌더에서 origin 드롭다운에 반영)
    if (resolvedOriginBranchId !== originBranchId) setOriginBranchId(resolvedOriginBranchId);

    const type = falladosMode ? 'fallado' : 'movido';

    // [Movidos Fix] parent(코드마드레) 행은 variantQuantities 를 자식 SKU 단위로 펼쳐서 보낸다.
    // 이전 버전은 parent.id 를 그대로 productId 로 보내, 실제 stock 이 variant 자식에 묶인 경우
    // 보고서 화면이 변동을 반영하지 못했다 (root cause: ProductList 2026-05-07 movidos 디버그 세션).
    // unresolved variant (stockByVariant 미보강) 가 있으면 즉시 throw — 잘못된 ID 로 전송 방지.
    const expandedItems: Array<{ productId: number; quantity: number }> = [];
    const unresolvedVariants: string[] = [];

    // [MOVIDOS-DEBUG] 펼치기 단계 추적 — fix 가 의도대로 parent → variant 자식으로 변환했는지 검증.
    // 안정화 후 제거 예정.
    const expansionTrace: Array<{
      parentIdx: number;
      parentId: number;
      parentName: string;
      mode: 'passthrough' | 'expanded' | 'skipped-zero-qty' | 'invalid';
      stockByVariantCount?: number;
      variantQuantitiesKeys?: string[];
      passthroughItem?: { productId: number; quantity: number };
      resolutions?: Array<{
        key: string;
        colorId: number;
        sizeId: number;
        qty: number;
        status: 'resolved' | 'unresolved';
        matchedSku?: string | null;
        matchedProductId?: number | null;
      }>;
    }> = [];

    products.forEach((p: any, idx: number) => {
      const parentId = Number(p?.id);
      const parentName = String(p?.name ?? '?');
      const hasVariants =
        p?.isParent === true &&
        p?.variantQuantities &&
        Object.keys(p.variantQuantities).length > 0;

      if (!hasVariants) {
        const pid = Number(p?.productId || p?.id);
        const qty = Number(p?.quantity);
        if (Number.isFinite(pid) && pid > 0 && qty > 0) {
          expandedItems.push({ productId: pid, quantity: qty });
          expansionTrace.push({
            parentIdx: idx,
            parentId,
            parentName,
            mode: 'passthrough',
            passthroughItem: { productId: pid, quantity: qty },
          });
        } else {
          expansionTrace.push({
            parentIdx: idx,
            parentId,
            parentName,
            mode: qty > 0 ? 'invalid' : 'skipped-zero-qty',
          });
        }

        return;
      }

      const stockByVariant = Array.isArray(p?.stockByVariant) ? p.stockByVariant : [];
      const resolutions: NonNullable<(typeof expansionTrace)[number]['resolutions']> = [];

      Object.entries(p.variantQuantities).forEach(([key, rawQty]) => {
        const qty = Number(rawQty);
        if (!qty || qty <= 0) return;

        const [colorIdStr, sizeIdStr] = String(key).split('-');
        const colorId = Number(colorIdStr);
        const sizeId = Number(sizeIdStr);
        const v = stockByVariant.find(
          (s: any) => s?.color?.id === colorId && s?.size?.id === sizeId,
        );
        const childPid = Number(v?.productId);
        if (Number.isFinite(childPid) && childPid > 0) {
          expandedItems.push({ productId: childPid, quantity: qty });
          resolutions.push({
            key,
            colorId,
            sizeId,
            qty,
            status: 'resolved',
            matchedSku: v?.sku ?? null,
            matchedProductId: childPid,
          });
        } else {
          unresolvedVariants.push(`parentId=${p.id} key=${key} qty=${qty}`);
          resolutions.push({ key, colorId, sizeId, qty, status: 'unresolved' });
        }
      });

      expansionTrace.push({
        parentIdx: idx,
        parentId,
        parentName,
        mode: 'expanded',
        stockByVariantCount: stockByVariant.length,
        variantQuantitiesKeys: Object.keys(p.variantQuantities),
        resolutions,
      });
    });

    if (unresolvedVariants.length > 0) {
      // 화면 새로고침으로 stockByVariant 가 채워진 후 재시도해야 한다 — silent send 차단
      const msg =
        `Variant productId 해석 실패 (${unresolvedVariants.length}건). ` +
        `cart 의 parent 항목을 제거 후 variant 그리드로 다시 추가하거나 페이지 새로고침 후 재시도. ` +
        `[${unresolvedVariants.slice(0, 3).join('; ')}${unresolvedVariants.length > 3 ? '...' : ''}]`;
      toast.error(msg);

      return;
    }

    if (expandedItems.length === 0) {
      toast.warning('전송할 item 이 없습니다 (수량 0 이거나 모두 무효).');

      return;
    }

    const payload = {
      type,
      storeId: user?.storeId,
      originBranchId: Number(resolvedOriginBranchId),
      targetBranchId: targetBranchId ? Number(targetBranchId) : null,
      items: expandedItems,
      notes: falladosMode ? 'Registro de productos fallados' : `Movimiento entre sucursales`,
    };

    // ── [MOVIDOS-DEBUG] 진단 로그 ──
    // 운영에서 "movido 등록 후 stock 변동 없음" 증상 추적용. 보내는/받는 지점 ID, 원본 cart 구조,
    // parent(코드마드레) 여부, 최종 payload 모두 노출하여 root cause 격리.
    // 추후 안정화 후 제거 예정 (PHASE 12 후속 / Phase 22 변동 무결성 작업과 함께).
    const correlationId = `MV-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    /* eslint-disable no-console */
    console.group(`[MOVIDOS-DEBUG] submit start ${correlationId}`);
    console.log('[MOVIDOS-DEBUG] mode:', { type, falladosMode, movidosMode });
    console.log('[MOVIDOS-DEBUG] branches:', {
      originBranchId,
      targetBranchId,
      originAsNumber: originBranchId ? Number(originBranchId) : null,
      targetAsNumber: targetBranchId ? Number(targetBranchId) : null,
      sameBranch: originBranchId && targetBranchId && originBranchId === targetBranchId,
    });
    console.log('[MOVIDOS-DEBUG] cart 원본 products[]:', products.map((p: any, idx: number) => ({
      idx,
      id: p?.id,
      productId: p?.productId,
      resolvedProductId: p?.productId || p?.id,
      isParent: p?.isParent === true,
      hasVariantQuantities: !!p?.variantQuantities,
      variantQuantitiesKeys: p?.variantQuantities ? Object.keys(p.variantQuantities) : null,
      stockByVariantCount: Array.isArray(p?.stockByVariant) ? p.stockByVariant.length : 0,
      quantity: p?.quantity,
      sku: p?.sku,
      name: p?.name,
    })));

    // [MOVIDOS-DEBUG] expansion 단계 추적 — fix 가 의도대로 펼쳤는지 확인
    console.log('[MOVIDOS-DEBUG] expansion trace (parent → variant 자식 매핑):', expansionTrace);
    console.log('[MOVIDOS-DEBUG] expandedItems[] (variant 자식 단위):', expandedItems);
    console.log('[MOVIDOS-DEBUG] 변환 요약:', {
      cartParentRows: products.length,
      parentsWithVariants: products.filter((p: any) => p?.isParent === true && p?.variantQuantities).length,
      passthroughRows: expansionTrace.filter((t) => t.mode === 'passthrough').length,
      expandedRows: expansionTrace.filter((t) => t.mode === 'expanded').length,
      skippedRows: expansionTrace.filter((t) => t.mode !== 'passthrough' && t.mode !== 'expanded').length,
      totalResolvedVariants: expansionTrace.reduce(
        (n, t) => n + (t.resolutions?.filter((r) => r.status === 'resolved').length ?? 0),
        0,
      ),
      finalPayloadItemCount: expandedItems.length,
    });

    // [MOVIDOS-DEBUG] 동일성 검증 — 수량 합이 cart total quantity 와 일치하는지 sanity check
    const cartTotalQty = products.reduce((sum: number, p: any) => sum + Number(p?.quantity || 0), 0);
    const payloadTotalQty = expandedItems.reduce((sum, it) => sum + it.quantity, 0);
    if (cartTotalQty !== payloadTotalQty) {
      console.warn(
        `[MOVIDOS-DEBUG] ⚠ 수량 불일치: cart total=${cartTotalQty} vs payload total=${payloadTotalQty} ` +
          `— 펼치기 로직에서 누락된 variant 가 있을 수 있음`,
      );
    }

    console.log('[MOVIDOS-DEBUG] 최종 payload (POST /stocks/movement):', payload);

    // [MOVIDOS-DEBUG] fix 검증 — payload.items 안에 parent productId 가 섞여 들어가는지 sanity check
    // (cart 의 parent.id 와 매칭되면 펼치기 실패. 정상이라면 모두 variant 자식 productId.)
    const cartParentIds = new Set(
      products.filter((p: any) => p?.isParent === true).map((p: any) => Number(p.id)),
    );
    const parentIdsLeakedToPayload = expandedItems.filter((it) => cartParentIds.has(it.productId));
    if (parentIdsLeakedToPayload.length > 0) {
      console.error(
        `[MOVIDOS-DEBUG] ❌ payload 에 parent productId 가 섞여 있음 (${parentIdsLeakedToPayload.length}건) — ` +
          `pre-fix 동작. 펼치기 로직 점검 필요.`,
        parentIdsLeakedToPayload,
      );
    } else if (cartParentIds.size > 0) {
      console.log(
        `[MOVIDOS-DEBUG] ✓ fix 검증 통과 — cart parent ${cartParentIds.size}개가 payload 에 ` +
          `섞이지 않음 (모두 variant 자식 productId 로 펼쳐짐)`,
      );
    }
    console.groupEnd();

    try {
      const t0 = performance.now();
      const response: any = await apiConnector.post("/stocks/movement", payload);
      const dt = Math.round(performance.now() - t0);

      console.group(`[MOVIDOS-DEBUG] response ${correlationId} (+${dt}ms)`);
      console.log('[MOVIDOS-DEBUG] backend response:', response);
      console.groupEnd();
      /* eslint-enable no-console */

      // Phase 35 (Plan 02): POST /stocks/movement 응답에 saleId 가 포함됨.
      // saleId 가 있으면 toast 에 "Ver detalle" 액션 링크 → /ventas?openSale={id} 로 navigate (D-11).
      // 누락 시 (legacy 백엔드 호환) 기존 단순 메시지만 표시.
      const saleId = response?.saleId ? Number(response.saleId) : null;
      const successMsg = falladosMode ? "Fallados registrados" : "Movimiento registrado";

      if (saleId && saleId > 0) {
        toast.success(
          ({ closeToast }: any) => (
            <span>
              {successMsg}
              {' · '}
              <a
                onClick={() => {
                  if (closeToast) closeToast();
                  void router.push(`/ventas?openSale=${saleId}`);
                }}
                style={{ cursor: 'pointer', textDecoration: 'underline', color: '#1976D2', fontWeight: 600 }}
              >
                Ver detalle
              </a>
            </span>
          ),
          { autoClose: 5000 },
        );
      } else {
        // legacy fallback — saleId 누락 (구 백엔드 / rollback) 시 단순 메시지
        toast.success(successMsg);
      }

      resetSale();
      setFalladosMode(false);
      setMovidosMode(false);
      setTargetBranchId('');
      if (props.onSaleCreated) props.onSaleCreated();
    } catch (error: any) {
      /* eslint-disable no-console */
      console.group(`[MOVIDOS-DEBUG] error ${correlationId}`);
      console.error('[MOVIDOS-DEBUG] full error:', error);
      console.error('[MOVIDOS-DEBUG] error.response:', error?.response);
      console.error('[MOVIDOS-DEBUG] error.response?.data:', error?.response?.data);
      console.error('[MOVIDOS-DEBUG] error.response?.status:', error?.response?.status);
      console.groupEnd();
      /* eslint-enable no-console */
      toast.error(error.response?.data?.message || "Error al registrar");
    }
  };

  // 장바구니 행 클릭 시 코드마드레 variant 그리드 복원
  const handleParentRowClicked = (rowData: any) => {
    if (!rowData?.id) return;

    // productOptions에서 해당 코드마드레 찾기
    const parentProduct = productOptions.find((p: any) => p.id === rowData.id);

    // ───── DEBUG: cart row 클릭 시 grid 복원 진단 (안정 후 제거) ─────
    // eslint-disable-next-line no-console
    console.log('[handleParentRowClicked]', {
      rowDataId: rowData?.id,
      rowDataName: rowData?.name,
      rowDataIsParent: rowData?.isParent,
      foundInProductOptions: !!parentProduct,
      sizes: parentProduct?.sizes?.length ?? 0,
      colors: parentProduct?.colors?.length ?? 0,
      stockByVariant: parentProduct?.stockByVariant?.length ?? 0,
      stockByVariantSample: parentProduct?.stockByVariant?.slice(0, 2)?.map((v: any) => ({
        color: v?.color?.name, size: v?.size?.name, stock: v?.stock,
      })),
    });

    // 선택 제품 사진 → ImgProducts (가장 큰 사진 표시). 없으면 clear.
    const pImgs: string[] = Array.isArray(parentProduct?.imageUrls) && parentProduct.imageUrls.length
      ? parentProduct.imageUrls
      : (parentProduct?.imageUrl ? [parentProduct.imageUrl] : []);
    setActiveProductImages(pImgs);

    if (parentProduct) {
      // context에 variant 데이터 설정 → VariantsStockVenta 그리드 표시
      setSizes(parentProduct.sizes || []);
      setColors(parentProduct.colors || []);
      const baseStock = parentProduct.stockByVariant || [];
      setStockByVariant(baseStock);

      // 다중 터미널 동시판매 대비: cart 행 복원 시점에도 최신 재고를 다시 읽어 덮어쓰기
      if (parentProduct.id) {
        fetchLiveStock(parentProduct.id, saleBranchId)
          .then((live) => setStockByVariant(mergeLiveStock(baseStock, live)))
          .catch(() => { /* 실패 시 in-memory 값 유지 */ });
      }
    }

    // 저장된 variantQuantities 복원
    setRestoredQuantities(rowData.variantQuantities || null);

    // 현재 편집 타겟 product 를 context 에 저장 — handleAddToCart 가 이 id 로 정확한 product 를 찾아 수량 update.
    // isParent 조건 제거 (variation 없는 단일 variant 제품도 클릭으로 편집 타겟 전환 가능).
    if (rowData?.id != null) {
      setActiveParentId(rowData.id);
    }
  };

  // ── codigos hijitos 표시 모드 (CodigosMadres 체크박스 해제) ──
  // showParentsState=false 이면 cart 의 parent 상품을 (color×size) 단위 가상 행으로 펼친다.
  // 가상 행은 __parentIdx, __variantKey 메타로 원본 parent 를 가리키므로 삭제/수정 시 매핑 가능.
  // suspender→recall 시 stockByVariant 가 누락될 수 있어, variantQuantities 만으로도 펼치도록 함 (Fix A).
  const displayProducts = useMemo(() => {
    if (showParentsState) return products;

    return products.flatMap((p: any, idx: number) => {
      if (p?.isParent !== true || !p?.variantQuantities) {
        return [{ ...p, __parentIdx: idx }];
      }

      const stockByVariant = Array.isArray(p?.stockByVariant) ? p.stockByVariant : [];
      const rows = Object.entries(p.variantQuantities)
        .filter(([, qty]) => Number(qty) > 0)
        .map(([key, qty]) => {
          const [colorIdStr, sizeIdStr] = key.split('-');
          const colorId = Number(colorIdStr);
          const sizeId = Number(sizeIdStr);
          const v = stockByVariant.find(
            (s: any) => s?.color?.id === colorId && s?.size?.id === sizeId,
          );
          const colorName = v?.color?.name || '';
          const sizeName = v?.size?.name || '';
          const variantName =
            v?.name ||
            `${p.customName || p.name}${colorName || sizeName ? ` (${[colorName, sizeName].filter(Boolean).join(' / ')})` : ''}`;

          return {
            id: v?.productId ?? p.id,
            productId: v?.productId ?? p.id,
            sku: v?.sku ?? p.sku,
            name: variantName,
            customName: p.customName || null,
            price: p.price,
            priceType: p.priceType,
            quantity: Number(qty),

            // 가상 행 표식 — parent 원본을 가리킴
            __parentIdx: idx,
            __variantKey: key,
            isParent: false,
          };
        });

      // variantQuantities 가 모두 0 이거나 비어있으면 parent 그대로 표시 (수량 0 표기)
      return rows.length > 0 ? rows : [{ ...p, __parentIdx: idx }];
    });
  }, [products, showParentsState]);

  const handleDeleteProduct = (displayIdx: number) => {
    const item = displayProducts[displayIdx];
    if (!item) return;

    // 가상 행(확장된 hijito) 삭제 — parent 의 variantQuantities 에서 해당 키 제거
    if (item.__variantKey != null && item.__parentIdx != null) {
      const parentIdx = item.__parentIdx;
      const variantKey = item.__variantKey;
      const newProducts = [...products];
      const parent = { ...newProducts[parentIdx] };
      const newVQ = { ...(parent.variantQuantities || {}) };
      delete newVQ[variantKey];
      const newTotal = Object.values(newVQ).reduce(
        (sum: number, q: any) => sum + (Number(q) > 0 ? Number(q) : 0),
        0,
      );
      if (newTotal <= 0) {
        // 모든 variant 0 → parent 자체 제거
        newProducts.splice(parentIdx, 1);
      } else {
        parent.variantQuantities = newVQ;
        parent.quantity = newTotal;
        newProducts[parentIdx] = parent;
      }
      setProducts(newProducts);

      return;
    }

    // 일반 행 삭제 — __parentIdx 가 원본 products 배열의 인덱스
    const realIdx = item.__parentIdx ?? displayIdx;
    const newProducts = [...products];
    newProducts.splice(realIdx, 1);
    setProducts(newProducts);
  };

  const handleEditProduct = (index: number) => {
    const productToEdit = products[index];
    const newProducts = [...products];
    newProducts.splice(index, 1);
    setProducts(newProducts);
    setEditingProduct({ ...productToEdit });
  };

  /**
   * 임시 고객 자동 등록 헬퍼 — selectedClient 없고 fullname 만 있는 경우.
   *
   * 사용 위치: F2 (handleSubmit) + handleSuspend
   * 반환:
   *   - selectedClient 가 이미 있으면 그대로 반환
   *   - fullname 비어있으면 null 반환 (호출 측이 Consumidor Final fallback 진행)
   *   - fullname 있으면 POST /clients/temp 호출 후 setSelectedClient 적용한 새 client 반환
   *   - 등록 실패 시 throw — 호출 측이 progress 중단해야 함
   */
  const ensureClientForCheckout = async (): Promise<any | null> => {
    if (selectedClient) return selectedClient;
    const pendingFullname = (clientFormData?.fullname || '').trim();
    if (pendingFullname.length === 0) return null; // → Consumidor Final fallback

    const created: any = await apiConnector.post('/clients/temp', {
      fullname: pendingFullname,
    });
    const tempClient = created?.data ?? created;
    if (tempClient && tempClient.id) {
      setSelectedClient(tempClient);
      toast.success(
        `Cliente temporal creado: ${tempClient.fullname} (${tempClient.document})`,
        { autoClose: 2000 },
      );

      return tempClient;
    }
    throw new Error('Cliente temporal: respuesta inválida del backend');
  };

  // 판매 일시 중단 → ventas_suspendidas 테이블에 저장
  const handleSuspend = async () => {
    if (!user || !user.storeId) {
      toast.error("Error: Usuario no autenticado o sin tienda asignada");

      return;
    }
    if (products.length === 0) {
      toast.warning("Agrega al menos un producto.");

      return;
    }

    // selectedClient 없고 fullname 만 있으면 임시 고객 자동 등록 → suspender 가 그 id 로 저장.
    // 미선택 + fullname 도 빈 경우만 Consumidor Final (id=5) fallback.
    let effectiveClient: any = null;
    try {
      effectiveClient = await ensureClientForCheckout();
    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || 'Error al crear cliente temporal.';
      toast.error(String(msg));

      return;
    }

    const subtotalCalc = products.reduce((acc: number, p: any) => acc + ((p.price ?? 0) * (p.quantity ?? 0)), 0);
    const _discountAmount = discounts.reduce((acc: number, d: any) => acc + (d.amountDiscount || 0), 0);
    const _rechargesAmount = recharges?.reduce((acc: number, r: any) => acc + (r.amountRecharge || 0), 0) || 0;
    const totalAmountCalc = subtotalCalc - _discountAmount + _rechargesAmount + (transport || 0);

    // Suspender items 는 **parent-level 유지** — restore 시 원본 cart 구조(1 parent = 1 라인) 재현 가능
    // variation 상품: variantQuantities 를 함께 보냄. 백엔드가 이 매핑으로 variant-level hold 이동 기록
    // 일반 상품: variantQuantities 없음 → 백엔드가 단일 이동 기록
    const suspendItems = products.map((p: any) => ({
      productId: p.productId || p.id,
      quantity: p.quantity,
      price: p.price,
      customName: p.customName || null,
      variantQuantities: p?.isParent === true && p?.variantQuantities ? p.variantQuantities : undefined,
    }));

    // suspended-sales 에 vendedor + provincia 도 함께 보관 (Phase 26 Wave 5)
    const suspendObject = {
      clientId: Number(effectiveClient?.clientId || effectiveClient?.id || 5), // 미선택 + fullname 빈 경우만 Consumidor Final
      storeId: user.storeId,
      branchId: cashRegister?.box?.branchId || (user as any)?.branchId || null,
      sellerId: selectedSeller?.id || null,
      provinceId: salesProvinceId || null,
      subtotal: subtotalCalc,
      discountAmount: _discountAmount,
      transport,
      totalAmount: totalAmountCalc,
      items: suspendItems,
      discounts: discounts.map((d: any) => ({
        name: d.name,
        amountDiscount: typeof d.amountDiscount === 'number' ? d.amountDiscount : 0,
      })),
      recharges: recharges.map((r: any) => ({
        name: r.name,
        amountRecharge: typeof r.amountRecharge === 'number' ? r.amountRecharge : 0,
      })),
      numPedido: suspendedNumPedido || undefined,
    };

    try {
      // 복원한 보류판매는 같은 ID/생성일을 유지하며 갱신하고, 신규 건만 생성한다.
      if (suspendedSaleId) {
        await apiConnector.put(`/suspended-sales/${suspendedSaleId}`, suspendObject);
      } else {
        await apiConnector.post("/suspended-sales", suspendObject);
      }
      toast.success("Venta suspendida correctamente");
      resetSale();
      if (props.onSaleCreated) props.onSaleCreated();
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Error al suspender la venta");
    }
  };

  const handleSubmit = async (
    action: "DRAFT" | "INVOICED",
    paymentsArg?: any[],
    printTicketOverride?: boolean,
    customSaleDate?: Date | string | null,
    openFacturarAfter?: boolean,
  ) => {

  if (!user || !user.storeId) {
    toast.error("Error: Usuario no autenticado o sin tienda asignada");

    return;
  }

  if (!user.id) {
    toast.error("Error: Usuario sin ID válido");

    return;
  }

  // 고객 미선택 시 Consumidor Final (id: 5) 자동 적용

  if (products.length === 0) {
    toast.warning("Agrega al menos un producto.");

    return;
  }

  const paymentList = paymentsArg ?? [];
  const subtotal = products.reduce((acc: any, product: any) => acc + ((product.price ?? 0) * (product.quantity ?? 0)), 0);
  const _discountAmount = discounts.reduce((acc: number, d: any) => acc + (d.amountDiscount || 0), 0);
  const _recharges = recharges?.reduce((acc: number, r: any) => acc + (r.amountRecharge || 0), 0) || 0;
  const _transport = transport;

  // Phase A 프로모션: 'Descuento x promoción' 이 _discountAmount 에 이미 포함 (SaleProductsContext 가 sync).
  // 별도 차감 없이 totalAmount = subtotal - _discountAmount + _recharges + _transport 만으로 정합.
  const totalAmount = subtotal - _discountAmount + _recharges + _transport;
  const totalPaid = paymentList.reduce((acc, p) => acc + (p.amount || 0), 0);

  // DRAFT(Suspender) → Borrador, INVOICED → 결제 금액에 따라 상태 결정
  const status = action === "DRAFT"
    ? "Borrador"
    : totalPaid === totalAmount ? "Pagado" : "Pendiente por pagar";

  // 판매 payload 의 items 를 variant 단위로 확장
  // - isParent=true + variantQuantities + stockByVariant 가 있으면 각 (color,size) → variant productId 로 분해
  // - 없으면 기존처럼 단일 item (일반 상품 / 복원된 suspender 등 fallback)
  const expandedItems = products.flatMap((p: any) => {
    if (p?.isParent === true && p?.variantQuantities && Array.isArray(p?.stockByVariant)) {
      const rows = Object.entries(p.variantQuantities)
        .filter(([, qty]) => Number(qty) > 0)
        .map(([key, qty]) => {
          const [colorIdStr, sizeIdStr] = key.split('-');
          const colorId = Number(colorIdStr);
          const sizeId = Number(sizeIdStr);
          const v = p.stockByVariant.find((s: any) => s?.color?.id === colorId && s?.size?.id === sizeId);

          return {
            productId: v?.productId ?? p.id,
            quantity: Number(qty),
            price: p.price,
            customName: p.customName || null,
          };
        });

      // 안전망: 분해 결과가 0개(예외적)라면 parent 로 한 건 전송
      return rows.length > 0
        ? rows
        : [{ productId: p.id, quantity: p.quantity, price: p.price, customName: p.customName || null }];
    }

    return [{
      productId: p.productId || p.id,
      quantity: p.quantity,
      price: p.price,
      customName: p.customName || null,
    }];
  });

  // Phase A 프로모션 — expandedItems 에 promo metadata 주입 + 보너스 라인 추가
  // products[lineIndex] → productId 매핑 후, 같은 productId 의 모든 expandedItem 에 메타데이터 적용.
  // bulk_tier: price 를 newUnitPrice 로 교체. buy_x_get_y: 보너스 라인(qty=bonusQty, price=0, isPromoFree=true) 추가.
  // 같은 promo 의 paid+free 라인은 동일 promoGroupId (UUID) 공유 → 환불 R1/R3 방어용.
  const productPromoMap = new Map<number, any>();
  products.forEach((p: any, idx: number) => {
    const applied = (promoResult?.appliedPromotions ?? []).find((a: any) => a.lineIndex === idx);
    if (applied) productPromoMap.set(Number(p.id), applied);
  });

  // promo 절약액은 'Descuento x promoción' 으로 SaleProductsContext 가 discounts 에 sync
  // → backend sale.discountAmount 에 자동 포함되므로, items 는 paid line 그대로 유지 (단순화).
  // 환불 방어를 위해 paid line 에 promotionId 메타만 추가. isPromoFree / promoGroupId 는
  // bonus line 이 없으므로 의미 없음. bulk_tier 의 newUnitPrice 는 그대로 적용.
  const itemsWithPromo: any[] = expandedItems.map((item: any) => {
    const promo = productPromoMap.get(Number(item.productId));
    if (!promo) return item;
    const finalPrice = promo.type === 'bulk_tier' && promo.newUnitPrice != null
      ? promo.newUnitPrice
      : item.price;

    return {
      ...item,
      price: finalPrice,
      promotionId: promo.promotionId,
    };
  });

  // 2026-05-05 — Crédito/Seña/Favor 결제수단은 backend 가 storeClientId 필수 검증.
  // selectedClient 에 storeClientId 가 있으면 그대로 보내고, 없으면 null (Consumidor Final 케이스).
  const resolvedStoreClientId =
    (selectedClient as any)?.storeClientId
    ?? (selectedClient as any)?.store_client_id
    ?? null;

  const saleObject = {
    clientId: Number(selectedClient?.clientId || selectedClient?.id || 5), // 미선택 시 Consumidor Final
    storeClientId: resolvedStoreClientId, // 2026-05-05 — Crédito 활성화 핵심 필드
    storeId: user.storeId,
    branchId: cashRegister?.box?.branchId || (user as any)?.branchId || null,
    sellerId: selectedSeller?.id || null,
    provinceId: salesProvinceId || selectedClient?.provinceId || null, // Wave 5: 벤타 지방 정보
    // Alt+F2 / Alt+Click "Generar Venta" 시 사용자가 선택한 customSaleDate. 없으면 businessDate.
    saleDate: customSaleDate ?? getBusinessDateAsDate(),
    subtotal,
    discount: 0,
    discountAmount: _discountAmount,
    transport: _transport,
    totalAmount,
    notes: "",
    taxes: 0,
    status,
    items: itemsWithPromo,
    paymentMethods: paymentList.map((p: any) => ({
      paymentMethodId: p.paymentMethodId || p.id,
      optionId: p.optionId || null,
      amount: p.amount,

      // 수표 결제 — 백엔드가 slug='cheque' 확인 후 cartera 에 수표 등록
      ...(p.cheque ? { cheque: p.cheque } : {}),
    })),
    discounts: discounts.map((d: any) => ({
      name: d.name,
      amountDiscount: typeof d.amountDiscount === 'number' ? d.amountDiscount : 0,
    })),
    recharges: recharges.map((r: any) => ({
      name: r.name,
      amountRecharge: typeof r.amountRecharge === 'number' ? r.amountRecharge : 0,
    })),
    printTicket: printTicketOverride !== undefined ? printTicketOverride : printTicket,
  };


  // Phase 64 W1 — 이 확정 시도의 멱등키. 실패 후 재시도해도 같은 키를 보내야
  // 서버가 "이미 만든 판매"로 인식한다(중복 판매 방지). 성공 시에만 폐기한다.
  if (!idempotencyKeyRef.current) {
    idempotencyKeyRef.current =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(36).slice(2)}`
  }

  try {
    const saleRes: any = await apiConnector.post("/sales", saleObject, {
      headers: { 'Idempotency-Key': idempotencyKeyRef.current },
    });
    const createdSale = saleRes?.data ?? saleRes;

    // 판매가 확정됐으므로 키를 폐기한다 — 다음 판매는 새 키를 발급받는다.
    idempotencyKeyRef.current = null;

    // 보류판매는 판매 생성이 성공한 뒤에만 제거한다. 클릭/복원 단계에서는 절대 삭제하지 않는다.
    if (suspendedSaleId) {
      try {
        await apiConnector.remove(`/suspended-sales/${suspendedSaleId}`);
      } catch (cleanupError: any) {
        console.error('[Suspended] venta creada, pero no se pudo eliminar la suspendida:', cleanupError);
        toast.warning(
          `Venta creada, pero la suspendida #${suspendedSaleId} sigue en la lista. Elim\u00ednala manualmente para evitar duplicados.`,
          { autoClose: false },
        );
      }
    }

    toast.success("Venta creada exitosamente");

    // Task 7 — AFIP FE 게이트 매장만 최근 판매 저장(Facturar 편의 버튼용). 비게이트 매장은 미사용.
    if (facturarGateOn) setLastSale(createdSale);

    // F10 발급 플로우: 판매 완료 직후 발급 프리뷰 모달 자동 오픈 (PV 있을 때만).
    // Cancelar(Esc) 하면 미발급 → 판매는 완료되고 Pendientes 에 남음.
    if (openFacturarAfter && feOn && defaultPv) setFacturarSale(createdSale);

    // ─── auto impTiq: 확정 판매 자동 출력 ───────────────────────────────────
    // 체크박스가 켜져 있고 INVOICED 플로우일 때만 print-agent 로 전송
    if (action === "INVOICED" && autoImpTiq) {
      try {
        // 체크박스 상태 조회와 동일한 해석(currentBranchId) 사용 — 지점 불일치 방지
        const resolvedBranchId = currentBranchId;

        if (resolvedBranchId) {
          const issuedAt = new Date();
          const printPayload = {
            branchId: resolvedBranchId,

            // terminalId: 터미널별 프린터 라우팅용 — 매핑된 comandera 로만 출력
            terminalId: cashRegister?.terminalId ?? null,

            // saleId: 백엔드에서 print_count++ 카운팅용 (확정 venta 만 카운트됨)
            saleId: createdSale?.id || null,
            ticketType: 'invoiced' as const,
            store: {
              name:    (user as any)?.storeName || 'VENTAGO',
              address: (user as any)?.storeAddress || '-',
              cuit:    (user as any)?.storeCuit || '-',
              phone:   (user as any)?.storePhone || '-',
            },
            invoice: {
              // 티켓에는 당일 순번(dailyNumber)을 인쇄한다. sales.number 컬럼은 존재하지 않아
              // 기존 코드는 항상 전역 PK(id) 로 폴백돼 "Venta # 71" 처럼 찍혔다.
              // 레거시 행(daily_number = 0/null)만 id 로 폴백.
              number: createdSale?.dailyNumber || createdSale?.id || null,
              id:     createdSale?.id || null,
              date:   issuedAt.toLocaleDateString('es-AR'),
              time:   issuedAt.toLocaleTimeString('es-AR'),
              seller: selectedSeller?.name || (user as any)?.fullName || (user as any)?.name || '-',

              // selectedClient 는 fullname 속성을 가진다(InfoClient/useSaleProducts). 과거 .name 만 읽어
              // 항상 'Consumidor Final' 로 폴백돼 티켓에 실제 고객명이 찍히지 않았다. fullname 우선.
              client: selectedClient?.fullname || (selectedClient as any)?.name || 'Consumidor Final',
            },
            items: products.map((p: any) => {
              // parent 행이면 variantQuantities + stockByVariant 로 변형 매트릭스 재구성
              const variants = buildPrintVariants(p);

              return {
                name:      p.name || p.description || '-',
                quantity:  p.quantity ?? 1,
                unitPrice: p.price ?? 0,
                subtotal:  (p.price ?? 0) * (p.quantity ?? 1),
                ...(variants ? { variants } : {}),
              };
            }),

            // Forma de Pago — 확정 판매 영수증에 결제 내역 노출
            paymentMethods: (paymentMethods || []).map((pm: any) => ({
              method: pm.title || pm.name || pm.slug || 'Efectivo',
              option: pm.option || null,
              amount: pm.amount,
            })),
            totals: {
              subtotal,
              discounts:   totalDiscounts,
              recharges:   totalRecharges,
              transport:   transport || 0,
              totalAmount: totalFactura,
            },
          };

          console.log('[autoImpTiq] → POST /print/temp (invoiced)', printPayload);
          const printRes: any = await apiConnector.post('/print/temp', printPayload);
          console.log('[autoImpTiq] ← response', printRes?.data ?? printRes);

          if ((printRes?.data ?? printRes)?.ok === false) {
            const reason = (printRes?.data ?? printRes)?.reason || (printRes?.data ?? printRes)?.error || 'desconocido';
            toast.error(`Print Agent: ${reason}`);
          }

          // 매핑 없는 터미널 → 지점 broadcast 로 출력됨 — 세션당 1회 경고
          warnPrintFallbackOnce(printRes, toast.warning);
        } else {
          console.warn('[autoImpTiq] branchId no resuelto — ticket no enviado');
        }
      } catch (printErr: any) {
        // 출력 실패는 판매에 영향 없음
        console.error('[autoImpTiq] ✗ print failed', printErr);
        toast.error(`No se pudo imprimir ticket: ${printErr?.message || 'error'}`);
      }
    }

    resetSale();
    window.dispatchEvent(new Event('saleCreated'));
    if (props.onSaleCreated) props.onSaleCreated();
  } catch (error: any) {
    toast.error(error.response?.data?.message || "Error al crear la venta");
  }
};

  const handleResetAll = () => {
    resetSale();

    // Task 7 fix — Esc 전체 리셋 시 이전 venta의 "Facturar venta #N" 버튼이 화면에 남지 않도록 클리어
    setLastSale(null);
    setFacturarSale(null);
    toast.info("Contexto de venta borrado");
  };

  useHotkeys('esc', (event) => { event.preventDefault(); handleResetAll(); });

  // Alt+F2 / Alt+Click "Generar Venta" — 다른 날짜로 venta 등록 (예: 어제 매출 누락분).
  // 평소 (Alt 없음): 오늘(businessDate)로 venta.
  const [altDateDialogOpen, setAltDateDialogOpen] = useState(false);
  const [altSaleDate, setAltSaleDate] = useState<string>('');

  const submitVenta = useCallback(async (customSaleDate?: Date | null) => {
    if (!isValidPayment || !cashRegister?.terminal?.name || !cashRegister?.box?.name) return;

    // ───── DEBUG: Alt+F2 customSaleDate 전달 확인 (안정 후 제거) ─────
    // eslint-disable-next-line no-console
    console.log('[submitVenta] customSaleDate=', customSaleDate,
      '| isDate=', customSaleDate instanceof Date,
      '| valid=', customSaleDate instanceof Date ? !Number.isNaN(customSaleDate.getTime()) : 'n/a',
      '| iso=', customSaleDate instanceof Date && !Number.isNaN(customSaleDate.getTime()) ? customSaleDate.toISOString() : 'n/a');
    try {
      await ensureClientForCheckout();
    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || 'Error al crear cliente temporal.';
      toast.error(String(msg));

      return;
    }
    handleSubmit('INVOICED', paymentMethods, undefined, customSaleDate ?? null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isValidPayment, cashRegister, paymentMethods, selectedClient, clientFormData]);

  const tryGenerarVenta = useCallback((altKey: boolean) => {
    if (!isValidPayment || !cashRegister?.terminal?.name || !cashRegister?.box?.name) return;
    if (altKey) {
      // 다른 날짜로 등록 — date picker 표시
      const today = new Date();
      const iso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      setAltSaleDate(iso);
      setAltDateDialogOpen(true);

      return;
    }
    submitVenta();
  }, [isValidPayment, cashRegister, submitVenta]);

  // F2: 임시 고객 자동 등록(필요 시) + Generar Venta (판매 완료)
  // Alt+F2 (또는 Alt+Click 버튼): 다른 날짜로 등록 다이얼로그 표시
  //
  // 흐름:
  //   - selectedClient 있음 → 그대로 venta
  //   - selectedClient 없음 + fullname 입력만 있음 → 임시 고객 자동 등록 후 venta
  //   - 둘 다 없음 → Consumidor Final 로 venta (백엔드 fallback)
  useHotkeys('f2,alt+f2', (event) => {
    event.preventDefault();
    tryGenerarVenta(event.altKey === true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tryGenerarVenta]);

  // F10: 판매 완료 + AFIP 영수증 발급 프리뷰 자동 오픈 (F2 는 발급 없이 완료).
  const submitVentaConFactura = useCallback(async () => {
    if (!isValidPayment || !cashRegister?.terminal?.name || !cashRegister?.box?.name) return;

    // 오프라인 차단: AFIP 실시간 발급 불가 → 발급 시도 자체를 막고 F2 로 안내.
    // 판매를 잃지 않도록 "F2 로 완료, 복구 후 발급" 메시지 제공.
    if (isOffline) {
      toast.error('Sin conexión: no se puede facturar (AFIP). Usá F2 para completar la venta — la factura queda pendiente hasta recuperar internet.');

      return;
    }
    if (!feOn) {
      toast.info('Facturación electrónica no habilitada');

      return;
    }
    if (!defaultPv) {
      toast.error('No hay punto de venta AFIP configurado');

      return;
    }
    try {
      await ensureClientForCheckout();
    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || 'Error al crear cliente temporal.';
      toast.error(String(msg));

      return;
    }
    handleSubmit('INVOICED', paymentMethods, undefined, null, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isValidPayment, cashRegister, paymentMethods, feOn, defaultPv, selectedClient, clientFormData, isOffline]);

  useHotkeys('f10', (event) => {
    event.preventDefault();
    submitVentaConFactura();
  }, { preventDefault: true, enableOnFormTags: true }, [submitVentaConFactura]);

  // F7: Vendedor 선택 필드로 점프 (브라우저 캐럿 브라우징 방지)
  useHotkeys('f7', (event) => {
    event.preventDefault();
    event.stopPropagation();
    const vendedorInput = document.getElementById('input-vendedor');
    if (vendedorInput) vendedorInput.focus();
  }, { preventDefault: true, enableOnFormTags: true });

  // F8: Cantidad 필드로 점프 + 내용 초기화
  useHotkeys('f8', (event) => {
    event.preventDefault();
    const cantidadInput = document.getElementById('input-cantidad') as HTMLInputElement;
    if (cantidadInput) {
      cantidadInput.focus();
      cantidadInput.select();
    }
  });

  // Ctrl+Q: QMode 토글
  useHotkeys('ctrl+q', () => setQMode((q: boolean) => !q), []);

  // Ctrl+S: Suspender (판매 일시 중단) — 브라우저 "페이지 저장" 기본 동작 차단,
  // 입력 필드(스캐너/cantidad 등) 포커스 중에도 동작하도록 enableOnFormTags 허용
  useHotkeys('ctrl+s', (event) => {
    event.preventDefault();
    handleSuspend();
  }, { preventDefault: true, enableOnFormTags: true });

  // F11: 사용하지 않음 (결제 모달은 InvoiceAditional 칩에서 열림)

    useEffect(() => {
      if (showParentsState && productOptions.length > 0) {
        const allSizes: any[] = [];
        const allColors: any[] = [];
        productOptions.forEach(prod => {
          if (prod.sizes) allSizes.push(...prod.sizes);
          if (prod.colors) allColors.push(...prod.colors);
        });
        const newSizes = [...new Set(allSizes.map(s => s.id))].map(id => allSizes.find(s => s.id === id));
        const newColors = [...new Set(allColors.map(c => c.id))].map(id => allColors.find(c => c.id === id));

        const arraysEqual = (a: any[], b: any[]) =>
          a.length === b.length && a.every((v, i) => v?.id === b[i]?.id);

        setSizes((prevSizes: any[]) => {
          if (!arraysEqual(prevSizes, newSizes)) {
            return newSizes;
          }

          return prevSizes;
        });
        setColors((prevColors: any[]) => {
          if (!arraysEqual(prevColors, newColors)) {
            return newColors;
          }

          return prevColors;
        });
      }
    }, [showParentsState, productOptions, setSizes, setColors]);

  return (
    <GroupBox
      title={
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <span style={{ whiteSpace: 'nowrap', marginRight: 100 }}>Nueva Venta</span>
          <FormControlLabel
            control={<Checkbox size="small" checked={qMode} onChange={e => setQMode(e.target.checked)} sx={{ p: 0.3 }} />}
            label="QMode"
            sx={{ m: 0, '& .MuiTypography-root': { fontSize: '0.7rem', whiteSpace: 'nowrap' } }}
          />
          <FormControlLabel
            control={<Checkbox size="small" checked={showParentsState} onChange={e => setShowParentsState(e.target.checked)} sx={{ p: 0.3 }} />}
            label="CodigosMadres"
            sx={{ m: 0, '& .MuiTypography-root': { fontSize: '0.7rem', whiteSpace: 'nowrap' } }}
          />
          <FormControlLabel
            control={<Checkbox size="small" checked={false} onChange={() => {}} sx={{ p: 0.3 }} />}
            label="Devolver Ropas"
            sx={{ m: 0, '& .MuiTypography-root': { fontSize: '0.7rem', whiteSpace: 'nowrap' } }}
          />
          {branches.length > 1 && (
            <>
              <FormControlLabel
                control={<Checkbox size="small" checked={movidosMode} onChange={e => {
                  const checked = e.target.checked;
                  setMovidosMode(checked);
                  if (checked) {
                    setFalladosMode(false);
                    setSelectedClient({ id: null, fullname: '[Movidos]', document: '00000000' });
                    clearProducts();
                  } else {
                    setTargetBranchId('');
                    setOriginBranchId((user as any)?.branchId ? String((user as any).branchId) : '');
                    setSelectedClient(null);
                  }
                }} sx={{ p: 0.3 }} />}
                label="Movidos"
                sx={{ m: 0, '& .MuiTypography-root': { fontSize: '0.7rem', whiteSpace: 'nowrap' } }}
              />
              {movidosMode && (
                <>
                  <CustomTextField
                    select
                    size="small"
                    value={originBranchId}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      setOriginBranchId(e.target.value);
                      if (e.target.value === targetBranchId) setTargetBranchId('');
                    }}
                    SelectProps={{ displayEmpty: true }}
                    sx={{ minWidth: 110, '& .MuiInputBase-root': { height: 22, fontSize: '0.7rem' } }}
                  >
                    <MenuItem value="" disabled><em>Origen</em></MenuItem>
                    {branches
                      .filter((b: any) => String(b.id) !== targetBranchId)
                      .map((b: any) => (
                        <MenuItem key={b.id} value={String(b.id)}>{b.name}</MenuItem>
                      ))}
                  </CustomTextField>
                  <span style={{ fontSize: '0.7rem', whiteSpace: 'nowrap' }}>→</span>
                  <CustomTextField
                    select
                    size="small"
                    value={targetBranchId}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTargetBranchId(e.target.value)}
                    SelectProps={{ displayEmpty: true }}
                    sx={{ minWidth: 110, '& .MuiInputBase-root': { height: 22, fontSize: '0.7rem' } }}
                  >
                    <MenuItem value="" disabled><em>Destino</em></MenuItem>
                    {branches
                      .filter((b: any) => String(b.id) !== originBranchId)
                      .map((b: any) => (
                        <MenuItem key={b.id} value={String(b.id)}>{b.name}</MenuItem>
                      ))}
                  </CustomTextField>
                </>
              )}
            </>
          )}
          <FormControlLabel
            control={<Checkbox size="small" checked={falladosMode} onChange={e => {
              const checked = e.target.checked;
              setFalladosMode(checked);
              if (checked) {
                setMovidosMode(false);
                setTargetBranchId('');

                // Phase 35 회귀 수정 — fallado 활성화 시 originBranchId 를 user.branchId 로 강제 동기화.
                // movido checkbox 와 동일 패턴. fast-refresh / 다른 mode 전환으로 originBranchId 가
                // 비어있을 때 fallado 단독 등록이 400 (originBranchId es requerido) 으로 실패하던 버그.
                setOriginBranchId((user as any)?.branchId ? String((user as any).branchId) : '');
                setSelectedClient({ id: null, fullname: '[Fallados]', document: '00000000' });
                clearProducts();
              } else {
                setSelectedClient(null);
              }
            }} sx={{ p: 0.3 }} />}
            label="Fallados"
            sx={{ m: 0, '& .MuiTypography-root': { fontSize: '0.7rem', whiteSpace: 'nowrap' } }}
          />
        </Box>
      }
      sx={{ backgroundColor: 'white', marginBottom: 2, marginTop: 2, flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}
    >

      <ProductInputs
        productOptions={productOptions}
        loading={loading}
        error={error}
        showParents={showParentsState}
        setShowParents={setShowParentsState}
        onAddProduct={handleAddProduct}
        editingProduct={editingProduct}
        clearEditingProduct={() => setEditingProduct(null)}
        qMode={qMode}
        setQMode={setQMode}
        saleBranchId={saleBranchId}
      />

      {/* {showParentsState && (
        <VariantsStockVenta />
      )} */}

      <PromoBannerStack />

      <Box sx={{ flex: 1, minHeight: 0, overflow: 'auto', mt: '5px' }}>
        <ProductListTable
          addedProducts={displayProducts}
          handleEditProduct={handleEditProduct}
          handleDeleteProduct={handleDeleteProduct}
          clientExpanded={props.clientExpanded}
          codigosMadresMode={showParentsState}
          onParentRowClicked={handleParentRowClicked}
          onUpdateProduct={(displayIdx: number, updated: any) => {
            const item = displayProducts[displayIdx];
            if (!item) return;

            // 가상 hijito 행 — parent 의 variantQuantities[key] 만 갱신
            if (item.__variantKey != null && item.__parentIdx != null) {
              const parentIdx = item.__parentIdx;
              const variantKey = item.__variantKey;
              const newProducts = [...products];
              const parent = { ...newProducts[parentIdx] };
              const newVQ: Record<string, number> = { ...(parent.variantQuantities || {}) };
              const newQty = Number(updated.quantity) || 0;
              if (newQty > 0) {
                newVQ[variantKey] = newQty;
              } else {
                delete newVQ[variantKey];
              }
              const newTotal = Object.values(newVQ).reduce(
                (sum: number, q: any) => sum + (Number(q) > 0 ? Number(q) : 0),
                0,
              );
              if (newTotal <= 0) {
                newProducts.splice(parentIdx, 1);
              } else {
                parent.variantQuantities = newVQ;
                parent.quantity = newTotal;

                // price 인라인 수정도 parent 단가에 반영 (모든 variant 가 동일 가격 사용)
                if (updated.price !== undefined) parent.price = updated.price;
                if (updated.customName !== undefined && parent.isGeneric) {
                  parent.customName = updated.customName;
                  parent.name = updated.customName;
                }
                newProducts[parentIdx] = parent;
              }
              setProducts(newProducts);

              return;
            }

            // 일반 행 — __parentIdx 가 실제 products 인덱스
            const realIdx = item.__parentIdx ?? displayIdx;
            const newProducts = [...products];
            const original = { ...newProducts[realIdx] };

            // 메타 필드 제거하고 본 데이터만 머지
            const { __parentIdx, __variantKey, ...rest } = updated;
            void __parentIdx; void __variantKey;
            newProducts[realIdx] = { ...original, ...rest };
            setProducts(newProducts);
          }}
        />
      </Box>
      <Grid container spacing={1} sx={{ flexShrink: 0 }}>
        <Grid item xs={12} md={8}>
          <Box sx={{ p: 1, borderRight: { md: '1px solid #eee' } }}>
            {/* Phase 29 — cashRegister + handleSubmit 전달 (MP QR 자동 Generar Venta) */}
            <InvoiceAditional cashRegister={cashRegister} handleSubmit={handleSubmit} />
          </Box>
        </Grid>
        <Grid item xs={12} md={4}>
          <PaymentSummary addedProducts={products} sale={props.sale} />
        </Grid>
      </Grid>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 1, flexShrink: 0 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Button
            variant="outlined"
            color="secondary"
            size='small'
            onClick={handleResetAll}
          >
            <Icon icon="bx:reset" width={25} height={25} />
          </Button>
          <Typography style={{ fontWeight: 600 }}>
            Total Prendas: {totalPrendas}
          </Typography>
        </Box>
        {isSpecialMode ? (
          <Box sx={{ display: "flex", gap: 2 }}>
            <Button
              variant="contained"
              color={falladosMode ? "error" : "warning"}
              size="small"
              onClick={handleSubmitSpecial}
              disabled={products.length === 0}
            >
              {falladosMode ? "Registrar Fallados" : "Registrar Movimiento"}
            </Button>
          </Box>
        ) : (
          <WithFunctionAccess functionSlug="crear-venta">
            <Box sx={{ display: "flex", gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                color="info"
                onClick={async () => {
                  // print-agent로 임시(견적) 영수증 전송 — 브라우저 인쇄창 사용 안 함
                  // 체크박스 상태 조회와 동일한 해석(currentBranchId) 사용
                  const resolvedBranchId = currentBranchId;

                  console.log('[Imprimir Temp] click', {
                    resolvedBranchId,
                    cashRegisterBox: cashRegister?.box,
                    userKeys: user ? Object.keys(user as any) : null,
                  });

                  if (!resolvedBranchId) {
                    toast.error('No se pudo resolver la sucursal. ¿Caja abierta?');

                    return;
                  }

                  try {
                    const payload = {
                      branchId: resolvedBranchId,

                      // terminalId: 터미널별 프린터 라우팅용
                      terminalId: cashRegister?.terminalId ?? null,
                      ticketType: 'temp' as const,
                      store: {
                        name:    (user as any)?.storeName || 'VENTAGO',
                        address: (user as any)?.storeAddress || '-',
                        cuit:    (user as any)?.storeCuit || '-',
                        phone:   (user as any)?.storePhone || '-',
                      },
                      seller: selectedSeller?.name || (user as any)?.fullName || '-',
                      client: selectedClient?.name || 'Consumidor Final',
                      items: products.map((p: any) => ({
                        name:      p.name || p.description || '-',
                        quantity:  p.quantity ?? 1,
                        unitPrice: p.price ?? 0,
                        subtotal:  (p.price ?? 0) * (p.quantity ?? 1),
                      })),
                      totals: {
                        subtotal:    subtotal,
                        discounts:   totalDiscounts,
                        recharges:   totalRecharges,
                        transport:   transport || 0,
                        totalAmount: totalFactura,
                      },
                    };

                    const res: any = await apiConnector.post('/print/temp', payload);

                    if (res?.ok === false) {
                      toast.error(res?.error || 'No se pudo enviar al print-agent');

                      return;
                    }
                    toast.success('Presupuesto enviado al print-agent');

                    // 매핑 없는 터미널 → 지점 broadcast — 세션당 1회 경고
                    warnPrintFallbackOnce(res, toast.warning);
                  } catch (err: any) {
                    // 에러 핸들링: 네트워크/인증 실패 모두 사용자에게 안내
                    toast.error(`Error: ${err?.message || 'envío fallido'}`);
                  }
                }}
                disabled={products.length === 0}
              >
                Imprimir Temp
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={handleSuspend}
              >
                Suspender (Ctrl+S)
              </Button>
              {/* auto impTiq — 체크 시 Generar Venta 성공 후 자동으로 print-agent 로 티켓 전송 */}
              {/* 온라인 thermal 에이전트 없으면 체크박스는 disabled + 툴팁, 강제로 켜려 해도 toast 경고 */}
              <Tooltip
                title={hasOnlineThermalAgent ? '' : 'No hay una comandera (print-agent) conectada'}
                arrow
                disableHoverListener={hasOnlineThermalAgent}
              >
                <span>
                  <FormControlLabel
                    control={
                      <Checkbox
                        size="small"
                        checked={autoImpTiq}
                        onChange={handleAutoImpTiqChange}
                        disabled={!hasOnlineThermalAgent}
                        sx={{ p: 0.5 }}
                      />
                    }
                    label={<Typography variant="caption" sx={{ fontSize: 11 }}>auto impTiq</Typography>}
                    sx={{ mr: 0.5, ml: 0 }}
                  />
                </span>
              </Tooltip>
              {/* comandera 상태 pill — socket push 로 실시간 갱신 (폴링 없음) */}
              {/* 🟢 매핑 online / 🟡 매핑 없음(broadcast) / 🔴 offline */}
              {(() => {
                const pill = mappedThermalAgent
                  ? mappedThermalAgent.isOnline
                    ? { emoji: '🟢', text: mappedThermalAgent.label, tip: `Comandera asignada a esta terminal: ${mappedThermalAgent.label}`, color: 'success.main' }
                    : { emoji: '🔴', text: mappedThermalAgent.label, tip: `La comandera asignada (${mappedThermalAgent.label}) está desconectada`, color: 'error.main' }
                  : hasOnlineThermalAgent
                    ? { emoji: '🟡', text: 'Sin asignar', tip: 'Esta terminal no tiene comandera asignada — los tickets se imprimen en todas las comanderas de la sucursal. Asigne una en Sucursales → Terminales.', color: 'warning.main' }
                    : { emoji: '🔴', text: 'Sin comandera', tip: 'No hay ninguna comandera (print-agent) conectada en esta sucursal', color: 'error.main' };

                return (
                  <Tooltip title={pill.tip} arrow>
                    <Box
                      sx={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 0.5,
                        px: 1,
                        py: 0.25,
                        borderRadius: 4,
                        border: '1px solid',
                        borderColor: 'divider',
                        cursor: 'default',
                        alignSelf: 'center',
                      }}
                    >
                      <Typography variant="caption" sx={{ fontSize: 10, lineHeight: 1 }}>{pill.emoji}</Typography>
                      <Typography variant="caption" sx={{ fontSize: 10, lineHeight: 1, color: pill.color, maxWidth: 90, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {pill.text}
                      </Typography>
                    </Box>
                  </Tooltip>
                );
              })()}
              <Tooltip
                title={
                  !cashRegister?.terminal?.name || !cashRegister?.box?.name
                    ? "Debes seleccionar una caja y una terminal"
                    : "Alt + Click (o Alt+F2) → registrar con otra fecha"
                }
                arrow
              >
                <span>
                  <Button
                    variant="contained"
                    color="success"
                    size="small"
                    onClick={(e) => tryGenerarVenta(e.altKey)}
                    disabled={!isValidPayment || !cashRegister?.terminal?.name || !cashRegister?.box?.name}
                  >
                    Generar Venta (F2)
                  </Button>
                </span>
              </Tooltip>
              {/* Task 7 — POS Facturar 편의 버튼: FE 활성 + 수동 발급(afipAutoIssue=false) 매장만, 직전 판매 완료 후 노출 */}
              {facturarGateOn && lastSale && (
                <Tooltip
                  title={isOffline
                    ? 'Sin conexión: la facturación AFIP no está disponible'
                    : `Emitir comprobante AFIP para la venta #${lastSale.id}`}
                  arrow
                >
                  {/* 오프라인 시 비활성 버튼도 Tooltip 이 뜨도록 span 래핑 */}
                  <span>
                    <Button
                      variant="outlined"
                      color="info"
                      size="small"
                      disabled={isOffline}
                      onClick={() => setFacturarSale(lastSale)}
                    >
                      Facturar venta #{lastSale.id}
                    </Button>
                  </span>
                </Tooltip>
              )}
            </Box>
          </WithFunctionAccess>
        )}
      </Box>

      {/* Alt+F2 / Alt+Click 시 다른 날짜로 등록 — 정오 12:00 사용 (timezone 안전) */}
      <Dialog open={altDateDialogOpen} onClose={() => setAltDateDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>Registrar venta con otra fecha</DialogTitle>
        <DialogContent dividers>
          <Typography variant="body2" sx={{ mb: 1.5 }}>
            Detectamos <strong>Alt</strong> al confirmar. Elige la fecha de la venta:
          </Typography>
          <TextField
            type="date"
            size="small"
            fullWidth
            value={altSaleDate}
            onChange={e => setAltSaleDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            autoFocus
          />
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
            La hora se fija a las 12:00 (mediodía) para evitar problemas de zona horaria.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAltDateDialogOpen(false)}>Cancelar</Button>
          <Button
            variant="contained"
            color="success"
            disabled={!altSaleDate}
            onClick={() => {
              setAltDateDialogOpen(false);
              const d = new Date(`${altSaleDate}T12:00:00`);
              submitVenta(d);
            }}
          >
            Confirmar venta · {altSaleDate}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Task 7 — POS Facturar 편의 버튼의 부분 발급 모달 (Task 4 재사용). facturarSale=null 이면 미렌더. */}
      {facturarSale && defaultPv && (
        <PartialInvoiceModal
          sale={facturarSale}
          pv={defaultPv}
          defaultPct={afipDefaultPct}
          onClose={() => setFacturarSale(null)}
          onIssued={() => {
            setFacturarSale(null);
            setLastSale(null);
          }}
        />
      )}
    </GroupBox>
  );
};

export default ProductList;
