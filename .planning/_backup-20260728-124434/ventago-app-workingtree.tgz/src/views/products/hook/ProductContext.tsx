
import React, { createContext, useContext, useState } from "react";
import { DateTime } from 'luxon';

const ProductContext = createContext<any>(null);

export const ProductProvider = ({ children }: any) => {
  const [product, setProduct] = useState<any>({});
  const [variants, setVariants] = useState<any[]>([]);
  const [prices, setPrices] = useState<any[]>([]);
  const [sizes, setSizes] = useState<any[]>([]);
  const [colors, setColors] = useState<any[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<any[]>([]);
  const [selectedColors, setSelectedColors] = useState<any[]>([]);
  const [priceTypes, setPriceTypes] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [subcategories, setSubcategories] = useState<any[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>(DateTime.now().toFormat('yyyy-MM-dd'));
  const [mode, setMode] = useState<'add' | 'edit'>('add');
  const [loading, setLoading] = useState(false);
  const [originalStocks, setOriginalStocks] = useState<any[]>([]);

  // 재입고 수정 시 가격 변경 감지를 위한 원본 가격 스냅샷
  const [originalPrices, setOriginalPrices] = useState<any[]>([]);
  const [originalBasePrice, setOriginalBasePrice] = useState<number | null>(null);

  // CodigoMadre 편집 모드: 부모 제품의 기존 variant를 편집
  // { parentId, parentName, parentSku, children, deletedVariantIds }
  const [editingMadre, setEditingMadre] = useState<any>(null);

  // 폼 데이터만 초기화 — 참조 데이터 + 분류/공급자 선택은 유지
  // → 동일 타입/공급자의 연속 입력을 위해 categories, supplierId, originId, seasonId 보존
  const resetAll = () => {
    setProduct((prev: any) => ({
      categories: prev.categories,
      subcategories: prev.subcategories,
      supplierId: prev.supplierId,
      originId: prev.originId,
      seasonId: prev.seasonId,
    }));
    setVariants([]);
    setPrices([]);
    setSelectedSizes([]);
    setSelectedColors([]);
    setSelectedDate(DateTime.now().toFormat('yyyy-MM-dd'));
    setMode('add');
    setLoading(false);
    setOriginalStocks([]);
    setOriginalPrices([]);
    setOriginalBasePrice(null);
    setEditingMadre(null);
  };

  return (
    <ProductContext.Provider value={{
      product,
      setProduct,
      variants,
      setVariants,
      prices,
      setPrices,
      sizes,
      setSizes,
      colors,
      setColors,
      selectedSizes,
      setSelectedSizes,
      selectedColors,
      setSelectedColors,
      priceTypes,
      setPriceTypes,
      categories,
      setCategories,
      subcategories,
      setSubcategories,
      selectedDate,
      setSelectedDate,
      mode,
      setMode,
      loading,
      setLoading,
      originalStocks,
      setOriginalStocks,
      originalPrices,
      setOriginalPrices,
      originalBasePrice,
      setOriginalBasePrice,
      editingMadre,
      setEditingMadre,
      resetAll
    }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProductContext = () => useContext(ProductContext);
