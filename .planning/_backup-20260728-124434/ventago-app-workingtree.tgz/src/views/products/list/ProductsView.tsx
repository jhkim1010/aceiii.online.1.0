import { Alert, Box, Button, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions, Typography } from "@mui/material";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ProductsList from "./components/ProductsList";
import BasicDataCard from "./components/BasicDataCard";
import apiConnector from "src/services/api.service";
import toast from "react-hot-toast";
import VariantsStock from "./components/VariantsStock";
import { useAuth } from "src/hooks/useAuth";
import ProductParentList from "./components/ProductParentList";
import { useProductContext } from "src/views/products/hook/ProductContext";
import ProductPhotoBox from "src/components/product/ProductPhotoBox";
import SelectorBranch from "./components/SelectorBranch";
import { devLog } from "src/utils/dev-logger";
import { filterVisiblePriceTypes, recalculateDerivedPrices } from "src/utils/price-types";
import { useSizesByStore } from "src/hooks/api/useSizesByStore";
import { useColorsByStore } from "src/hooks/api/useColorsByStore";
import { usePriceTypes } from "src/hooks/api/usePriceTypes";
import { useCategoriesByStore } from "src/hooks/api/useCategoriesByStore";
import { useSubcategoriesByStore } from "src/hooks/api/useSubcategoriesByStore";

const ProductsView = () => {
  const {
    product, setProduct,
    variants, setVariants,
    prices, setPrices,
    sizes, setSizes,
    colors, setColors,
    selectedSizes, setSelectedSizes, setSelectedColors,
    priceTypes, setPriceTypes,
    setCategories,
    setSubcategories,
    selectedDate, setSelectedDate,
    mode, setMode,
    loading, setLoading,
    resetAll,
    originalStocks, setOriginalStocks,
    originalPrices, setOriginalPrices,
    originalBasePrice, setOriginalBasePrice,
    editingMadre, setEditingMadre,
  } = useProductContext();
  const { user } = useAuth();

  // StoreConfig — /configuracion/productos 의 useColor/useSize 토글 반영
  // (ProductsView 진입 시 1회 로드, useColor && useSize 둘 다 false 면 단순 모드)
  const [storeConfig, setStoreConfig] = useState<any | null>(null);
  useEffect(() => {
    if (!user?.storeId) return;
    apiConnector.get(`/store-config/${user.storeId}`).then((res: any) => {
      setStoreConfig(res);
    }).catch(() => {
      setStoreConfig(null);
    });
  }, [user?.storeId]);

  // variant 사용 여부 결정 우선순위:
  //   1. stores.useVariants = false → 단순 모드 (관리자 명시적 비활성화)
  //   2. storeConfig.useColor 와 storeConfig.useSize 둘 다 false → 단순 모드 (기존 토글 호환)
  //   3. 그 외 → 기존 variants 모드
  const storeUseVariants = user?.useVariants ?? true;
  const bothVariantFlagsOff = storeConfig
    ? storeConfig.useColor === false && storeConfig.useSize === false
    : false;
  const useVariants = storeUseVariants && !bothVariantFlagsOff;

  // 단순 모드 전용: 등록할 총 수량
  const [cantidad, setCantidad] = useState<number>(0);
  const [refreshProducts, setRefreshProducts] = useState(false);
  const [selectedBranches, setSelectedBranches] = useState<any[]>([]);

  // 저장 에러 — 인라인 prominent Alert(에러 가시성 정책: toast 와 이중 노출의 한 축)
  const [submitError, setSubmitError] = useState<string | null>(null);

  // SelectorBranch 전환 감지용 — 이전 branchId 추적해서
  //   * 초기 자동선택은 무시
  //   * 실제 사용자 전환일 때만 그리드 수량 0 초기화 / 신규 endpoint 호출
  // sentinel(undefined) 로 "최초 마운트" 와 "deselect (null)" 을 구분.
  const prevBranchIdRef = useRef<number | null | undefined>(undefined);

  // CodigoMadre 클릭 → 부모 정보(category/supplier/season/origin/description/prices) 자동 채우기 + variants 그리드 채우기
  // ProductParentList.loadCodigoMadre 와 동일한 동작 — 두 클릭 경로(좌측 ProductsList MadreView / 우측 ProductParentList) 대칭화
  const handleMadreClick = useCallback(async (detail: import('./components/ProductsList').MadreChildrenDetail | null) => {
    if (!detail) {
      setEditingMadre(null);

      return;
    }

    // ── 1) 백엔드에서 부모 + variants 상세 조회.
    //   지점이 선택돼 있으면 inventory-by-date-branch (그 지점만), 없으면 inventory-by-date (전체 합).
    //   → SelectorBranch 의 선택 상태와 그리드 표시값이 항상 일치 (부분 선택 시 합산값 노출 방지).
    const branchScope = selectedBranches[0]?.id ?? null;
    const branchStockMap = new Map<string, number>();
    let inventoryVariants: any[] = []; // inventory-by-date* 응답의 전체 variants — children fallback 으로 사용

    console.log('[MADRE-CLICK]', '진입', {
      parentId: detail.parentId,
      parentName: detail.parentName,
      parentSku: detail.parentSku,
      childrenCount: detail.children?.length || 0,
      branchScope,
      selectedDate,
    });
    try {
      // selectedDate 가 있으면 그 날짜를, 없으면 오늘 사용. 어제 입고된 product 도 조회 가능하도록.
      // (이전 동작: 항상 today 로 하드코딩 → 과거 날짜 입고 variant 는 stock=0 으로 잡혀 제외됨)
      const checkDate =
        selectedDate ||
        (() => {
          const today = new Date();
          const yyyy = today.getFullYear();
          const mm = String(today.getMonth() + 1).padStart(2, '0');
          const dd = String(today.getDate()).padStart(2, '0');

          return `${yyyy}-${mm}-${dd}`;
        })();
      console.log('[MADRE-CLICK]', `inventory 조회 — checkDate=${checkDate}, branch=${branchScope}`);
      const res: any = branchScope
        ? await apiConnector.get(
            `/products/${detail.parentId}/inventory-by-date-branch`,
            { date: checkDate, branchId: branchScope },
          )
        : await apiConnector.get(
            `/products/${detail.parentId}/inventory-by-date`,
            { date: checkDate },
          );
      const data = res?.data || res || {};
      const parent = data.parent || {};

      console.log('[MADRE-CLICK]', 'inventory 응답', {
        parentId: parent.id,
        parentSku: parent.sku,
        variantsLen: Array.isArray((data as any).variants) ? (data as any).variants.length : 0,
        sample: Array.isArray((data as any).variants)
          ? (data as any).variants.slice(0, 3).map((v: any) => ({
              vid: v.id ?? v.productId,
              c: v.color?.id,
              s: v.size?.id,
              stock: v.stock,
            }))
          : null,
      });

      // 전체 variants 캡처 — detail.children 가 stock-today 필터로 일부 누락된 경우 fallback 으로 사용.
      if (Array.isArray((data as any).variants)) {
        inventoryVariants = (data as any).variants;
      }

      // 지점 선택 시 data.variants 에서 (colorId-sizeId → branch stock) 매핑 구축
      if (branchScope && Array.isArray((data as any).variants)) {
        for (const v of (data as any).variants) {
          const cId = v.color?.id;
          const sId = v.size?.id;
          if (cId && sId) branchStockMap.set(`${cId}-${sId}`, Number(v.stock) || 0);
        }
        console.log('[MADRE-CLICK]', 'branchStockMap 구축', {
          entries: branchStockMap.size,
          keys: Array.from(branchStockMap.keys()).slice(0, 10),
        });
      }

      // 가격 결정: parent.prices 가 비어있으면 첫 variant 의 prices 를 fallback 으로 사용.
      // 이유: codigo madre 부모 자체는 prices 가 없고 각 variant 에만 있는 케이스가 있음.
      //   화면(BasicDataCard) 의 PRECIO BASE / REC.21 / DES.5 / DES.3 등이 0 으로 표시되는 버그 해결.
      const sourcePricesArr =
        Array.isArray(parent.prices) && parent.prices.length > 0
          ? parent.prices
          : (Array.isArray((data as any).variants) &&
            (data as any).variants[0]?.prices?.length > 0
              ? (data as any).variants[0].prices
              : []);
      const sourcePriceBase =
        parent.price != null && Number(parent.price) > 0
          ? Number(parent.price)
          : (sourcePricesArr.length > 0 ? Number(sourcePricesArr[0].amount) || 0 : 0);

      console.log('[MADRE-CLICK]', '가격 소스 결정', {
        parentPricesLen: Array.isArray(parent.prices) ? parent.prices.length : 0,
        firstVariantPricesLen: Array.isArray((data as any).variants) && (data as any).variants[0]?.prices ? (data as any).variants[0].prices.length : 0,
        sourcePricesLen: sourcePricesArr.length,
        sourcePriceBase,
      });

      // 메인 폼(BasicDataCard) 을 부모 정보로 채움
      setProduct({
        id: parent.id,
        parentId: parent.id,
        sku: parent.sku || detail.parentSku || '',

        // serial 컬럼 — 자동 SKU(autoSku=true)로 생성된 상품만 값이 있음(수동/재입고는 NULL)
        serial: parent.serial ?? null,
        name: parent.name || detail.parentName || '',
        description: parent.description || '',
        imageUrl: parent.imageUrl,
        status: parent.status || 'active',
        categories: parent.categories || (parent.categoryId ? [parent.categoryId] : []),
        subcategories: parent.subcategories || [],
        supplierId: parent.supplierId,
        seasonId: parent.seasonId,
        originId: parent.originId,
        price: sourcePriceBase,

        // 멀티스토어 공유 토글 — backend 가 응답에 포함하면 사용, 없으면 false
        allowRevendedor: parent.allowRevendedor ?? false,
        publishMarketplace: parent.publishMarketplace ?? false,

        // 공개몰(Tienda Web) 게시 여부 — madre 클릭 시 현재 상태 반영
        isPublishedShop: parent.isPublishedShop ?? false,
      });
      setOriginalBasePrice(sourcePriceBase);

      // 가격: priceTypeId 기준 주입 + 원본 스냅샷 (재입고 diff 비교용)
      if (sourcePricesArr.length > 0) {
        const mappedPrices = sourcePricesArr.map((p: any) => ({
          priceTypeId: p.priceTypeId || p.priceType?.id,
          amount: Number(p.amount) || 0,
          currency: p.currency || 'ARS',
        }));
        setPrices(mappedPrices);
        setOriginalPrices(mappedPrices.map((p: any) => ({ ...p })));
      } else {
        setOriginalPrices([]);
      }
    } catch (err) {
      devLog('STOCK', 'handleMadreClick: 부모 상세 조회 실패 — 기본 채우기만 진행', err);
    }

    const colorMap = new Map<number, { colorId: number; colorName: string; isExisting: true; stocks: any[] }>();
    const talleSet = new Map<number, { id: number; name: string }>();

    // 그리드 소스 결정:
    //   - inventory 응답에 variants 가 있으면 우선 사용 (parent 의 모든 variant — 어제/오늘 무관 전체)
    //   - 없으면 detail.children 사용 (stock-today 응답 — 오늘 입고된 row 만, 일부 누락 가능)
    const gridSource: any[] =
      inventoryVariants.length > 0 ? inventoryVariants : detail.children;

    console.log('[MADRE-CLICK]', 'gridSource 선택', {
      usingInventoryVariants: inventoryVariants.length > 0,
      inventoryVariantsLen: inventoryVariants.length,
      detailChildrenLen: detail.children?.length || 0,
      sourceLen: gridSource.length,
    });

    let totalChildrenProcessed = 0;
    let qtyZeroCount = 0;
    let qtyPositiveCount = 0;
    for (const child of gridSource) {
      const colorId = child.color?.id || child.colorId;
      const colorName = child.color?.name || '—';
      const sizeId = child.size?.id || child.sizeId;
      const sizeName = child.size?.name || '—';

      // qty 결정 우선순위:
      //   1. 지점 선택됨 → branchStockMap 에서 (color-size) → 그 지점 stock
      //   2. 지점 미선택 + stockAddedToday 필드 존재 (detail.children) → 그 값
      //   3. inventoryVariants 에서 직접 stock 필드 사용 (전체 합)
      //   4. 모두 없으면 0
      let qty: number;
      if (branchScope) {
        qty = branchStockMap.get(`${colorId}-${sizeId}`) ?? 0;
      } else if (child.stockAddedToday !== undefined) {
        qty = Number(child.stockAddedToday) || 0;
      } else if (child.stock !== undefined) {
        qty = Number(child.stock) || 0;
      } else {
        qty = 0;
      }

      totalChildrenProcessed++;
      if (qty > 0) qtyPositiveCount++;
      else qtyZeroCount++;

      if (sizeId) talleSet.set(sizeId, { id: sizeId, name: sizeName });

      if (!colorMap.has(colorId)) {
        colorMap.set(colorId, { colorId, colorName, isExisting: true, stocks: [] });
      }

      // qty=0 인 variant 도 stocks 에 추가 (어제/이전 입고 codigo 도 그리드에 노출).
      if (sizeId) {
        colorMap.get(colorId)!.stocks.push({ sizeId, stock: qty });
      }
    }

    console.log('[MADRE-CLICK]', 'children → grid 매핑 결과', {
      totalChildrenProcessed,
      qtyPositiveCount,
      qtyZeroCount,
      uniqueColors: colorMap.size,
      uniqueSizes: talleSet.size,
      colorIds: Array.from(colorMap.keys()),
      sizeIds: Array.from(talleSet.keys()),
    });

    const talles = Array.from(talleSet.values());
    setSelectedSizes(talles);

    const existingVariants = Array.from(colorMap.values()).map(v => ({
      colorId: v.colorId,
      stocks: v.stocks,
      _isExisting: true,
      _colorName: v.colorName,
    }));
    const emptyRows = Array.from({ length: 4 }, () => ({ colorId: '', stocks: [], _isExisting: false }));
    setVariants([...existingVariants, ...emptyRows]);

    // ── 3) editingMadre 상태 설정 ──
    setEditingMadre({
      parentId: detail.parentId,
      parentName: detail.parentName,
      parentSku: detail.parentSku,
      originalChildren: detail.children,
      deletedColorIds: [],
    });

    // madre 진입 직후 첫 effect 호출에서 불필요한 fetch 방지 — 현재 지점을 prev 로 동기화
    prevBranchIdRef.current = selectedBranches[0]?.id ?? null;
  }, [setProduct, setPrices, setOriginalPrices, setVariants, setSelectedSizes, setEditingMadre, selectedBranches, selectedDate]);

  // Serial input 클릭 → 새 제품 입력 모드 진입
  // 유지: categories, subcategories, supplierId, originId (같은 배치 연속 입력 지원)
  // 청소: 제품 고유 정보 (id/parentId/sku/name/description/price/imageUrl/seasonId) + prices/variants/cantidad/selectedBranches/editingMadre
  // serial 은 SKU 자동 재생성 useEffect 가 nextSerial 을 재조회하여 반영
  const handleStartNewProduct = useCallback(() => {
    setProduct((prev: any) => ({
      categories: prev.categories,
      subcategories: prev.subcategories,
      supplierId: prev.supplierId,
      originId: prev.originId,
    }));
    setPrices([]);
    setOriginalPrices([]);
    setOriginalBasePrice(null);
    setVariants([]);
    setSelectedSizes([]);
    setSelectedColors([]);
    setOriginalStocks([]);
    setEditingMadre(null);
    setMode('add');
    setCantidad(0);
    setSelectedBranches([]);
  }, [setProduct, setPrices, setOriginalPrices, setOriginalBasePrice, setVariants, setSelectedSizes, setSelectedColors, setOriginalStocks, setEditingMadre, setMode]);

  // 재입고 수정(stock/가격 정정) 확인 다이얼로그용 상태
  const [openEditConfirm, setOpenEditConfirm] = useState(false);
  const [editDiffPreview, setEditDiffPreview] = useState<Array<{
    variantId: number;
    colorLabel: string;
    sizeLabel: string;
    oldStock: number;
    newStock: number;
  }>>([]);
  const [editPriceDiff, setEditPriceDiff] = useState<Array<{
    priceTypeId: number;
    label: string;
    oldAmount: number;
    newAmount: number;
  }>>([]);
  const [editBasePriceDiff, setEditBasePriceDiff] = useState<{ oldAmount: number; newAmount: number } | null>(null);

  // ── 좌우 Resizable split pane (상하는 고정, Historial이 남는 공간 자동) ──
  const RESIZER_W = 8;
  const MIN_LEFT = 360;
  const MIN_RIGHT = 280;
  const MIN_HIST = 200;      // Historial 최소 높이 (입력폼이 너무 클 때 보호)
  const DEFAULT_LEFT_PERCENT = 65;
  const splitRef = useRef<HTMLDivElement>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const [leftPaneW, setLeftPaneW] = useState<number | null>(null);

  // ── 우측 패널 내부 상하 분할 (Variantes ↔ Códigos madres) ──
  const RESIZER_H = 8;
  const MIN_VARIANTS_H = 280;  // VariantsStock 최소 높이 (너무 작아지지 않게)
  const MIN_PARENT_H = 140;    // Códigos madres 최소 높이
  const DEFAULT_VARIANTS_H = 420;
  const rightPanelRef = useRef<HTMLDivElement>(null);
  const [variantsH, setVariantsH] = useState<number>(DEFAULT_VARIANTS_H);

  // 좌우 + 상하 드래그 상태
  const dragState = useRef<{ type: 'lr' | 'tb' | null; startPos: number; startSize: number }>({
    type: null, startPos: 0, startSize: 0,
  });

  // 좌우 리사이저 mousedown
  const onLRResizerMouseDown = useCallback((e: React.MouseEvent) => {
    dragState.current = { type: 'lr', startPos: e.clientX, startSize: leftPaneW ?? 0 };
    document.body.style.cursor = 'ew-resize';
    document.body.style.userSelect = 'none';
  }, [leftPaneW]);

  // 우측 패널 내부 상하 리사이저 mousedown
  const onTBResizerMouseDown = useCallback((e: React.MouseEvent) => {
    dragState.current = { type: 'tb', startPos: e.clientY, startSize: variantsH };
    document.body.style.cursor = 'ns-resize';
    document.body.style.userSelect = 'none';
  }, [variantsH]);

  // 초기 leftPaneW 계산
  useEffect(() => {
    if (leftPaneW === null && splitRef.current) {
      const containerW = splitRef.current.offsetWidth;
      setLeftPaneW(Math.round(containerW * DEFAULT_LEFT_PERCENT / 100));
    }
  }, [leftPaneW]);

  // 좌우 드래그 mousemove/mouseup
  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      const ds = dragState.current;
      if (!ds.type) return;

      if (ds.type === 'lr' && splitRef.current) {
        const containerW = splitRef.current.offsetWidth;
        const available = containerW - RESIZER_W;
        const delta = e.clientX - ds.startPos;
        setLeftPaneW(Math.max(MIN_LEFT, Math.min(ds.startSize + delta, available - MIN_RIGHT)));
      }

      if (ds.type === 'tb' && rightPanelRef.current) {
        // 우측 패널 가용 높이 계산 — SelectorBranch 와 padding 등을 빼고 남은 공간
        const containerH = rightPanelRef.current.offsetHeight;
        const maxVariants = containerH - RESIZER_H - MIN_PARENT_H;
        const delta = e.clientY - ds.startPos;
        const next = Math.max(MIN_VARIANTS_H, Math.min(ds.startSize + delta, maxVariants));
        setVariantsH(next);
      }
    };
    const onMouseUp = () => {
      dragState.current = { type: null, startPos: 0, startSize: 0 };
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);

    return () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  // 참조 데이터 — SWR 캐시 (5분 dedup, 중복 API 호출 제거)
  const { data: swrSizes } = useSizesByStore();
  const { data: swrColors } = useColorsByStore();
  const { data: swrPriceTypes } = usePriceTypes();
  const { data: swrCategories } = useCategoriesByStore();
  const { data: swrSubcategories } = useSubcategoriesByStore();

  // SWR 데이터 → Context 동기화
  useEffect(() => {
    if (swrSizes) setSizes(Array.isArray(swrSizes) ? swrSizes : []);
  }, [swrSizes, setSizes]);

  useEffect(() => {
    if (swrColors) setColors(Array.isArray(swrColors) ? swrColors : []);
  }, [swrColors, setColors]);

  // 수동 레벨(increaseValue=0)도 표시 — base 성격(PRECIO 1)만 Precio base 와 중복이라 제외
  useEffect(() => {
    if (swrPriceTypes) {
      const list = (swrPriceTypes as any)?.data || swrPriceTypes;
      setPriceTypes(filterVisiblePriceTypes(list, user?.storeId));
    }
  }, [swrPriceTypes, setPriceTypes, user?.storeId]);

  useEffect(() => {
    if (swrCategories) setCategories((swrCategories as any)?.data ?? swrCategories);
  }, [swrCategories, setCategories]);

  useEffect(() => {
    if (swrSubcategories) setSubcategories((swrSubcategories as any)?.data ?? swrSubcategories);
  }, [swrSubcategories, setSubcategories]);

  // 단순 모드 cantidad 상태 초기화: product / mode 리셋 시 (resetAll 호출로 product 빈 상태 복귀 감지)
  // selectedBranches 도 동시에 비워야 새 codigo madre 생성 시 이전 선택 잔류 방지
  useEffect(() => {
    if (mode === 'add' && !product?.name && !product?.id) {
      setCantidad(0);
      setSelectedBranches([]);
    }
  }, [mode, product?.name, product?.id]);

  // SelectorBranch 전환 시 그리드 동기화:
  //   * 신규 제품(parentId 없음) → 그리드 보존 + 수량만 0
  //   * 기존 제품 + 지점 선택 → 그 지점 + selectedDate 의 입고 조회 (inventory-by-date-branch)
  //   * 기존 제품 + deselect (null) → 전체 합산 (inventory-by-date)
  //   첫 마운트 시점은 sentinel(undefined) 로 구분해서 자동선택을 무시.
  useEffect(() => {
    const newBranchId = selectedBranches[0]?.id ?? null;
    const prev = prevBranchIdRef.current as number | null | undefined;

    // 최초 진입 / 마운트 — 추적만 시작
    if (prev === undefined) {
      prevBranchIdRef.current = newBranchId as any;

      return;
    }

    // 동일 상태
    if (prev === newBranchId) return;

    prevBranchIdRef.current = newBranchId as any;

    const productId = editingMadre?.parentId ?? product?.id ?? product?.parentId;

    if (!productId) {
      // 신규 제품 — 그리드 보존, 모든 사이즈 셀을 0으로 (stocks 가 비어 있던 행도 채움)
      setVariants((prevVariants: any[]) => prevVariants.map((row: any) => ({
        ...row,
        stocks: selectedSizes
          .filter((sz: any) => sz?.id)
          .map((sz: any) => ({ sizeId: sz.id, stock: 0 })),
      })));

      return;
    }

    // 기존 제품 — branchId 있으면 지점별, 없으면 전체 합산
    let cancelled = false;
    const fetchPromise = newBranchId
      ? apiConnector.get(`/products/${productId}/inventory-by-date-branch`, {
          date: selectedDate,
          branchId: newBranchId,
        })
      : apiConnector.get(`/products/${productId}/inventory-by-date`, {
          date: selectedDate,
        });

    fetchPromise
      .then((res: any) => {
        if (cancelled) return;
        const data = res?.data || res || {};
        const branchVariants = Array.isArray(data.variants) ? data.variants : [];
        const stockMap = new Map<string, number>();
        for (const v of branchVariants) {
          const cId = v.color?.id ?? v.colorId;
          const sId = v.size?.id ?? v.sizeId;
          if (cId && sId) stockMap.set(`${cId}-${sId}`, Number(v.stock) || 0);
        }

        // selectedSizes 컬럼을 기준으로 stocks 를 재구성 — 기존 stocks 가 비어 있어도(초기 stock=0)
        // 모든 사이즈 셀이 stockMap 에서 값을 받아 표시되도록.
        setVariants((prevVariants: any[]) => prevVariants.map((row: any) => ({
          ...row,
          stocks: selectedSizes
            .filter((sz: any) => sz?.id)
            .map((sz: any) => ({
              sizeId: sz.id,
              stock: stockMap.get(`${row.colorId}-${sz.id}`) ?? 0,
            })),
        })));
      })
      .catch((err) => {
        if (cancelled) return;
        devLog('STOCK', 'inventory 조회 실패 — 0 으로 초기화', err);
        setVariants((prevVariants: any[]) => prevVariants.map((row: any) => ({
          ...row,
          stocks: selectedSizes
            .filter((sz: any) => sz?.id)
            .map((sz: any) => ({ sizeId: sz.id, stock: 0 })),
        })));
      });

    return () => {
      cancelled = true;
    };
  }, [selectedBranches, selectedDate, editingMadre?.parentId, product?.id, product?.parentId, setVariants, selectedSizes]);

  useEffect(() => {
    if (!product.price || !Array.isArray(priceTypes) || priceTypes.length === 0) return;

    // 편집 진입 시에는 원본 레벨을 보존하고, 사용자가 기준가를 실제 변경한 뒤에만 자동 레벨을 갱신한다.
    if ((mode === 'edit' || product.parentId) && Number(product.price) === Number(originalBasePrice)) return;

    // 수동 레벨(increaseValue=0)은 사용자가 입력한 값을 보존해야 하므로 함수형 업데이트 사용
    setPrices((prevPrices: any[]) => recalculateDerivedPrices(Number(product.price), priceTypes, prevPrices));
  }, [product.price, priceTypes, setPrices, mode, product.parentId, originalBasePrice]);


  // CodigoMadre 편집 저장
  const handleMadreSave = useCallback(async () => {
    if (!editingMadre || selectedBranches.length === 0) return;
    setLoading(true);
    try {
      const deleteColorIds: number[] = [];
      const addVariants: Array<{ colorId: number; sizeId: number; stock: number }> = [];
      const updateVariants: Array<{ variantId: number; newStock: number }> = [];

      for (const row of variants) {
        if (row._isExisting && row._deleted) {
          // 삭제 대상: colorId 수집
          deleteColorIds.push(row.colorId);
        } else if (row._isExisting && !row._deleted) {
          // 수량 수정 대상: originalChildren 에서 variantId 찾기.
          // 항상 push — originalChildren.stockAddedToday 는 집계값이라 새 지점에서
          // 같은 값이면 skip 되는 문제. 백엔드가 그 지점/날짜의 currentTotal 과 차분 계산.
          for (const s of row.stocks) {
            const origChild = editingMadre.originalChildren.find(
              (c: any) => (c.color?.id || c.colorId) === row.colorId && (c.size?.id || c.sizeId) === s.sizeId
            );
            if (origChild) {
              const newQty = Number(s.stock ?? 0);
              updateVariants.push({ variantId: origChild.id, newStock: newQty });
            }
          }
        } else if (!row._isExisting && row.colorId) {
          // 새 variant 추가 — stock=0 도 허용해야 codigo hijito 가 생성됨 (지점별 분배 use-case)
          for (const s of row.stocks) {
            const rawQty = s?.stock;
            const qty =
              rawQty === '' || rawQty === undefined || rawQty === null || Number.isNaN(Number(rawQty))
                ? 0
                : Number(rawQty);
            if (qty >= 0 && s.sizeId) {
              addVariants.push({ colorId: row.colorId, sizeId: s.sizeId, stock: qty });
            }
          }
        }
      }

      devLog('MADRE-EDIT', 'Guardar cambios', { deleteColorIds, addVariants, updateVariants });

      await apiConnector.put(`/products/${editingMadre.parentId}/edit-madre-variants`, {
        date: selectedDate || new Date().toISOString().slice(0, 10),
        branchIds: selectedBranches.map((b: any) => b.id),
        deleteColorIds,
        addVariants,
        updateVariants,
      });

      toast.success('Cambios guardados correctamente');
      resetAll();
      setRefreshProducts(prev => !prev);
    } catch (err: any) {
      devLog('MADRE-EDIT', 'Error', { message: err?.message, response: err?.response?.data });
      toast.error(err?.response?.data?.message || 'Error al guardar cambios');
    } finally {
      setLoading(false);
    }
  }, [editingMadre, variants, selectedBranches, selectedDate, setLoading, resetAll]);

  // CREAR PRODUCTO (modo add)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // editingMadre 모드: 별도 저장 흐름
    if (editingMadre) {
      return handleMadreSave();
    }

    devLog('STOCK', `handleSubmit 진입 — mode=${mode}`, {
      productId: product.id,
      productName: product.name,
      sku: product.sku,
      price: product.price,
      parentId: product.parentId,
      variantsCount: variants.length,
      branches: selectedBranches.map((b: any) => ({ id: b.id, name: b.name })),
    });
    devLog('STOCK', 'variants 상세', variants.map((row: any) => ({
      colorId: row.colorId,
      stocks: row.stocks.map((s: any) => ({ sizeId: s.sizeId, stock: s.stock })),
    })));

    // edit 모드(재입고/정정) 에서는 handleEdit 으로 위임 — 가격만 수정도 허용해야 함
    if (mode === 'edit') {
      return handleEdit(e);
    }
    if (!user?.storeId) {
      toast.error("Usuario no tiene tienda asignada");

      return;
    }

    // ── 단순 cantidad 모드 (useVariants=false) ──
    // stock 이 0 이어도 codigo hijito 생성을 허용 — 사용자가 SKU 만 먼저 등록하고 입고는 나중에 처리
    if (!useVariants) {
      if (cantidad === undefined || cantidad === null || Number(cantidad) < 0) {
        toast.error('La cantidad no puede ser negativa');

        return;
      }

      // 확인 다이얼로그 없이 즉시 저장 (사용자 요청)
      doSubmit();

      return;
    }

    // variants 모드도 stock=0 허용 — 색×사이즈 grid 만 정의하고 입고는 추후 처리하는 use-case 보호
    const totalStock = variants.reduce(
      (acc: number, row: any) =>
        acc + row.stocks.reduce((a: number, s: any) => a + Number(s.stock), 0),
      0
    );
    devLog('STOCK', `totalStock 계산 결과: ${totalStock} (0 허용)`);

    // 확인 다이얼로그 없이 즉시 저장 (사용자 요청)
    doSubmit();
  };

  const doSubmit = async () => {
    devLog('STOCK', 'doSubmit 시작 — 확인 다이얼로그 OK 클릭');
    setSubmitError(null);

    // 신규 생성 성공 시 서버 응답의 sku/serial 로 폼을 갱신하기 위한 임시 보관
    let createdSku: string | undefined;
    let createdSerial: number | null | undefined;
    try {
      if (!user?.storeId) {
        toast.error("Usuario no tiene tienda asignada");
        setLoading(false);

        return;
      }

      // 사진 갤러리 업로드 (최대 5장). imageFiles 배열 우선, 없으면 단일 imageFile 하위호환.
      // 순서 보존, [0]=대표(featured) → imageUrl, 전체 → imageUrls (WP 동기화 포함)
      let imageUrl: string | undefined = undefined;
      const imageUrls: string[] = [];
      const galleryFiles: File[] = Array.isArray(product.imageFiles) && product.imageFiles.length
        ? product.imageFiles
        : (product.imageFile ? [product.imageFile] : []);
      for (const file of galleryFiles.slice(0, 5)) {
        try {
          const formData = new FormData();
          formData.append('file', file);
          const result: any = await apiConnector.sendFile('/minio', formData);
          imageUrls.push(result?.fileName || file.name);
        } catch (err) {
          imageUrls.push(file.name);
        }
      }
      if (imageUrls.length) imageUrl = imageUrls[0];

      const { variantsToday = [] } = product;
      const existingVariants = Array.isArray(variantsToday) ? variantsToday : [];
      let validVariants: any[] = [];
      let colorIds: number[] = [];
      let sizeIds: number[] = [];
      let quantities: number[] = [];
      let totalStock = 0;

      if (!useVariants) {
        // ── 단순 모드: 기본 'Color Único' / 'Talle Única' id 재사용 (Products.colorId/sizeId NOT NULL) ──
        if (!defaultColorId || !defaultSizeId) {
          toast.error('Faltan entidades base (Color Único / Talle Única) en la tienda');
          setLoading(false);

          return;
        }

        // 기존 parent 존재 시 (재입고): 동일 colorId/sizeId 조합을 찾아 stock 증분
        const existingMatch = existingVariants.find(
          (v: any) =>
            (v.color?.id || v.colorId) === defaultColorId &&
            (v.size?.id || v.sizeId) === defaultSizeId,
        );
        if (existingMatch) {
          validVariants = [{
            id: existingMatch.id,
            colorId: defaultColorId,
            sizeId: defaultSizeId,
            stock: Number(existingMatch.stock) + cantidad,
            prices,
          }];
        } else {
          validVariants = [{
            colorId: defaultColorId,
            sizeId: defaultSizeId,
            stock: cantidad,
            prices,
          }];
        }
        colorIds = [defaultColorId];
        sizeIds = [defaultSizeId];
        quantities = [cantidad];
        totalStock = cantidad;
      } else {
        // ── 기존 variants 기반 (색×사이즈 grid) ──
        // 핵심: 사용자가 클릭/입력하지 않은 셀도 stock=0 으로 전송하여 codigo hijito 가 항상 생성되도록 함.
        // (예: 지점1 등록 시 일부 색은 0 으로 두고 지점2 에서 재입고 — 그래도 코드는 미리 생성되어야 함)
        const colorIdsSet = new Set<number>();
        const sizeIdsSet = new Set<number>();
        const validSizes = (selectedSizes || []).filter((sz: any) => sz?.id);
        const skippedCells: Array<{ rowIdx: number; reason: string }> = [];

        variants.forEach((row: any, rowIdx: number) => {
          const colorId = row.colorId;
          if (!colorId) {
            skippedCells.push({ rowIdx, reason: 'colorId 미선택' });

            return;
          }

          for (const sz of validSizes) {
            const sizeId = sz.id;

            // row.stocks 에서 해당 sizeId 조회. 없거나 빈 값이면 0 으로 간주 (codigo 생성 보장).
            const stockObj = row.stocks.find((s: any) => s.sizeId === sizeId);
            const rawStock = stockObj?.stock;
            const stock =
              rawStock === '' || rawStock === undefined || rawStock === null || Number.isNaN(Number(rawStock))
                ? 0
                : Number(rawStock);

            const found = existingVariants.find(
              (v: any) =>
                (v.color?.id || v.colorId) === colorId &&
                (v.size?.id || v.sizeId) === sizeId,
            );
            if (found) {
              validVariants.push({
                id: found.id,
                colorId,
                sizeId,
                stock: Number(found.stock) + stock,
                prices,
              });
            } else {
              validVariants.push({
                colorId,
                sizeId,
                stock,
                prices,
              });
            }
            colorIdsSet.add(colorId);
            sizeIdsSet.add(sizeId);
            quantities.push(stock);
          }
        });

        colorIds = Array.from(colorIdsSet);
        sizeIds = Array.from(sizeIdsSet);
        totalStock = quantities.reduce((acc, v) => acc + v, 0);

        devLog('STOCK', '[GRID-EXPAND] color×size 전체 grid 전송 (stock=0 셀 포함)', {
          totalCombosSent: validVariants.length,
          rowsProcessed: variants.length,
          validSizesCount: validSizes.length,
          colorIds,
          sizeIds,
          quantities,
          totalStock,
          skippedCells,
          combosWithStockZero: validVariants.filter((v: any) => Number(v.stock) === 0).length,
          combosWithStockPositive: validVariants.filter((v: any) => Number(v.stock) > 0).length,
        });
      }
      const { categories, ...productWithoutCategories } = product;
      const id = product.id;
      void categories;
      const branchIds = selectedBranches.map((b) => b.id);

      devLog('STOCK', 'validVariants 빌드 완료', {
        validVariantsCount: validVariants.length,
        validVariants,
        colorIds,
        sizeIds,
        quantities,
        totalStock,
        branchIds,
        parentId: id,
      });
      if (branchIds.length === 0) {
        toast.error('Debe seleccionar al menos una sucursal');
        setLoading(false);

        return;
      }
      let savedParentId: number | undefined = id;
      if (id) {
        devLog('STOCK', `기존 부모(id=${id})에 variants 추가`, { parentId: id, baseSku: product.sku, branchIds });
        const batchRes = await apiConnector.post('/products/variants/batch', {
          parentId: id,

          // baseSku 제거 — 서버가 parent.sku 를 접두로 강제(부모-변형 정합, Task 5)
          sizeIds,
          colorIds,
          quantities,
          variants: validVariants,
          branchIds,
          date: selectedDate, // 백엔드가 stocks.operation_date 로 저장 (백데이트 입고 지원)
        });
        devLog('STOCK', 'variants/batch 응답', batchRes);
        toast.success('Stock agregado correctamente');
      } else {
        // allowRevendedor/publishMarketplace는 product_visibility 테이블에서 관리하므로
        // 제품 데이터와 분리하여 전송
        // File 객체(imageFile/imageFiles/imageFilePreviews)는 JSON payload 에서 제외
        // — forbidNonWhitelisted 로 400 방지 + File 직렬화 불가. 실제 사진은 imageUrl/imageUrls 로 전송.
        const {
          allowRevendedor,
          publishMarketplace,
          imageFile: _imageFile,
          imageFiles: _imageFiles,
          imageFilePreviews: _imageFilePreviews,
          ...cleanProduct
        } = productWithoutCategories;
        void _imageFile;
        void _imageFiles;
        void _imageFilePreviews;
        const payload = {
          ...cleanProduct,

          // BasicDataCard 가 로컬 autoSku state(기본 true)를 product.autoSku 로 실어보냄 —
          // ...cleanProduct 에 이미 포함되지만 의도를 명시하기 위해 재확인 차 명시적으로 지정.
          // 서버가 이 값으로 serial 발급/조립 여부를 결정(미전송/undefined 시 서버 기본 true).
          autoSku: product.autoSku,
          storeId: user.storeId,
          categoryId: product.categories && product.categories.length > 0 ? product.categories[0] : undefined,
          subcategories: product.subcategories || [],
          description: product.description,
          stock: totalStock,
          price: Number(product.price),

          // 수동 레벨 입력 중 빈 문자열('') 이 남아있을 수 있으므로 숫자로 정규화
          prices: (prices || []).map((p: any) => ({ ...p, amount: Number(p.amount) || 0 })),
          isActive: true,

          // 멀티 스토어 공유 설정 (백엔드에서 product_visibility 테이블에 저장)
          allowRevendedor: allowRevendedor ?? false,
          publishMarketplace: publishMarketplace ?? false,

          // 대표 1장(기존 화면 호환) + 전체 갤러리(WP 동기화 포함)
          ...(imageUrl ? { imageUrl, imageUrls } : {})
        };
        devLog('STOCK', '신규 상품 생성 payload', payload);
        const result: any = await apiConnector.post('/products', payload);
        devLog('STOCK', 'POST /products 응답', result);
        devLog('STOCK', `variants/batch 호출 (parentId=${result.id})`, { branchIds, sizeIds, colorIds, quantities });
        await apiConnector.post('/products/variants/batch', {
          parentId: result.id,

          // baseSku 제거 — 서버가 parent.sku 를 접두로 강제(부모-변형 정합, Task 5)
          sizeIds,
          colorIds,
          quantities,
          variants: validVariants,
          branchIds,
          date: selectedDate,
        });
        savedParentId = result?.id;
        createdSku = result?.sku;
        createdSerial = result?.serial;
        toast.success('Producto creado correctamente');
      }
      setLoading(false);
      setRefreshProducts(prev => !prev);

      // parent 컨텍스트(id/sku/name/메타) 유지 — 신규 생성 직후 같은 부모로 재입고 가능하게.
      // 수량(0 으로 reset) 은 사용자가 SelectorBranch 에서 다른 지점을 클릭할 때 effect 가 처리.
      // 사용자 요청: agregar 후 같은 지점에서 입력값을 유지 — 다른 지점으로 전환 전까지는 reset 하지 않음.
      if (savedParentId) {
        setProduct((prev: any) => ({
          ...prev,
          id: savedParentId,
          parentId: savedParentId,

          // 서버가 조립한 최종 SKU/serial 반영(autoSku=true 면 서버가 프론트 sku 를 무시하고 재조립)
          ...(createdSku !== undefined ? { sku: createdSku } : {}),
          ...(createdSerial !== undefined ? { serial: createdSerial } : {}),
        }));
      }
    } catch (error: any) {
      devLog('STOCK', 'doSubmit 에러 발생', {
        message: error?.message,
        response: error?.response?.data,
        status: error?.response?.status,
      });

      // apiConnector 응답 인터셉터(api.service.ts)가 서버 응답을 new Error(response.data.message) 로
      // 재발행하면서 response/code 를 소실시킴 — error.response?.data?.code 검사는 항상 undefined.
      // error.message 에 서버 message 가 이미 담겨오므로 그대로 사용(SKU_SERIAL_EXHAUSTED 의 prefijo 교체
      // 안내 포함, 그 외 생성 실패 사유도 동일하게 노출) — 인라인 Alert + 토스트 이중 노출(에러 가시성 정책)
      const msg = error?.message || 'Error al crear el producto';
      setSubmitError(msg);
      toast.error(msg);
      setLoading(false);
    }
  };

  // ── 재입고 수정 흐름 ──
  // 1) handleEdit: 변경사항 diff 를 계산해서 confirm 다이얼로그를 띄운다
  // 2) doEdit: 사용자가 OK 를 누르면 새 correct-today 엔드포인트로 절대값 정정
  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.storeId) {
      toast.error("Usuario no tiene tienda asignada");

      return;
    }

    // variant.id (자식 Product.id) 단위로 newStock 합산
    // (한 색×사이즈 조합 = 한 variant 라는 전제. originalStocks 에 id 가 있어야 매칭)
    const variantTotals = new Map<number, { newStock: number; colorId: number; sizeId: number }>();
    for (const row of variants) {
      for (const stockObj of row.stocks) {
        if (!row.colorId || !stockObj.sizeId) continue;
        const original = originalStocks.find(
          (o: any) => o.colorId === row.colorId && o.sizeId === stockObj.sizeId,
        );
        if (!original?.id) continue; // 오늘 입고된 적 없는 조합은 정정 대상이 아님 (재입고는 add 모드)
        const newVal = Number(stockObj.stock);
        if (Number.isNaN(newVal)) continue;
        variantTotals.set(original.id, {
          newStock: newVal,
          colorId: row.colorId,
          sizeId: stockObj.sizeId,
        });
      }
    }

    // diff 계산: 실제로 변경된 항목만 표시
    const diff: typeof editDiffPreview = [];
    for (const [variantId, info] of variantTotals.entries()) {
      const original = originalStocks.find((o: any) => o.id === variantId);
      const oldStock = original ? Number(original.stock) : 0;
      if (oldStock === info.newStock) continue;
      const colorObj = colors.find((c: any) => c.id === info.colorId);
      const sizeObj = sizes.find((s: any) => s.id === info.sizeId);
      diff.push({
        variantId,
        colorLabel: colorObj?.name || `#${info.colorId}`,
        sizeLabel: sizeObj?.name || `#${info.sizeId}`,
        oldStock,
        newStock: info.newStock,
      });
    }

    // ── 가격 변경 감지 ──
    // 부모 클릭 시 받아둔 originalPrices 와 현재 prices 를 priceTypeId 단위로 비교
    const priceDiff: typeof editPriceDiff = [];
    for (const cur of prices) {
      const orig = originalPrices.find((o: any) => o.priceTypeId === cur.priceTypeId);
      const oldAmount = orig ? Number(orig.amount) || 0 : 0;
      const newAmount = Number(cur.amount) || 0;
      if (oldAmount === newAmount) continue;
      const pt = priceTypes.find((p: any) => p.id === cur.priceTypeId);
      priceDiff.push({
        priceTypeId: cur.priceTypeId,
        label: pt?.name || `#${cur.priceTypeId}`,
        oldAmount,
        newAmount,
      });
    }

    const oldBasePrice = Number(originalBasePrice) || 0;
    const newBasePrice = Number(product.price) || 0;
    const basePriceDiff = oldBasePrice === newBasePrice ? null : { oldAmount: oldBasePrice, newAmount: newBasePrice };

    if (diff.length === 0 && priceDiff.length === 0 && !basePriceDiff) {
      toast.success('No hay cambios para actualizar');

      return;
    }

    setEditDiffPreview(diff);
    setEditPriceDiff(priceDiff);
    setEditBasePriceDiff(basePriceDiff);
    setOpenEditConfirm(true);
  };

  const doEdit = async () => {
    if (!user?.storeId) return;
    setLoading(true);
    try {
      // 재입고 수정 흐름에서는 부모 메타데이터를 건드리지 않는다.
      // (사용자 의도는 stock 정정뿐이고, 이전 PUT /products/:id 호출은 DTO 화이트리스트 검증 때문에 400 으로 거부됨)
      const branchIds = selectedBranches.map((b: any) => b.id);
      if (branchIds.length === 0) {
        toast.error('Debe seleccionar al menos una sucursal');
        setLoading(false);
        setOpenEditConfirm(false);

        return;
      }

      const items = editDiffPreview.map(d => ({
        variantId: d.variantId,
        newStock: d.newStock,
      }));

      // 가격 변경분 (priceTypeId 단위로 절대값 amount 전송)
      const priceUpdates = editPriceDiff.map(p => ({
        priceTypeId: p.priceTypeId,
        amount: p.newAmount,
      }));

      await apiConnector.put(`/products/${product.id}/correct-today`, {
        date: selectedDate,
        branchIds,
        items,
        priceUpdates,
        ...(editBasePriceDiff ? { basePrice: editBasePriceDiff.newAmount } : {}),
      });

      toast.success('Cambios aplicados correctamente');
      setLoading(false);
      setOpenEditConfirm(false);
      setEditDiffPreview([]);
      setEditPriceDiff([]);
      setEditBasePriceDiff(null);
      setRefreshProducts(prev => !prev);

      // 편집 완료 직후 완전 청소 — variation/stock total 잔류 방지
      resetAll();
      setCantidad(0);
      setSelectedBranches([]);
    } catch (error: any) {
      console.error('[ProductsView] Error en doEdit', error);
      const msg = error?.response?.data?.message || error?.message || 'Error al corregir el stock';
      toast.error(typeof msg === 'string' ? msg : 'Error al corregir el stock');
      setLoading(false);
      setOpenEditConfirm(false);
    }
  };

  // 단순 모드 기본 id — 매장 최초 생성 시 storeTemplate 이 만든 'Color Único' / 'Talle Única'
  const defaultColorId = useMemo(
    () => (colors || []).find((c: any) => c.name === 'Color Único')?.id ?? null,
    [colors]
  );
  const defaultSizeId = useMemo(
    () => (sizes || []).find((s: any) => s.name === 'Talle Única')?.id ?? null,
    [sizes]
  );

  return (
    <>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', flex: 1, height: '100%', minHeight: 0 }}>
        {/*
          ── 전체 구조 (좌우 분할) ──
          container (flex row)
          ├─ 좌측 패널 (resizable width): ProductsList + 섹션라벨 + BasicDataCard
          ├─ resizer    : 세로 드래그 핸들
          └─ 우측 패널  : SelectorBranch + VariantsStock + ProductParentList
          action-bar    : 하단 고정 버튼
        */}
        <Box
          ref={splitRef}
          sx={{
            display: 'flex',
            flexDirection: 'column',
            flex: 1,
            minHeight: 0,
            overflow: 'hidden',
          }}
        >
          {/* ── 좌우 분할 영역 ── */}
          <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
            {/* ── 좌측 패널 (상하 분할 내장) ── */}
            <Box
              ref={leftPanelRef}
              sx={{
                width: leftPaneW ?? `${DEFAULT_LEFT_PERCENT}%`,
                minWidth: MIN_LEFT,
                flexShrink: 0,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              {/* Historial (남은 공간 자동 채움 — 입력폼은 자연 높이 우선) */}
              <Box sx={{
                flex: 1,
                minHeight: MIN_HIST,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                borderBottom: '1px solid #EEEEEE',
              }}>
                <ProductsList
                  refresh={refreshProducts}
                  selectedDate={selectedDate}
                  setSelectedDate={setSelectedDate}
                  onMadreClick={handleMadreClick}
                />
              </Box>

              {/* 하단: 입력폼 (자연 높이 — compact 레이아웃이라 작음) */}
              <Box sx={{ flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {/* 저장 에러 — 인라인 prominent Alert(toast 와 이중 노출, SKU_SERIAL_EXHAUSTED 등) */}
                {submitError && (
                  <Alert severity="error" variant="filled" sx={{ mx: 2 }} onClose={() => setSubmitError(null)}>
                    {submitError}
                  </Alert>
                )}

                {/* 섹션 라벨: ＋ Entrada de stock */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, flexShrink: 0, px: 2, pt: 1 }}>
                  <Box sx={{ flex: 1, height: '1px', background: '#E0E0E0' }} />
                  <Typography sx={{
                    fontSize: 11, fontWeight: 700, color: '#9E9E9E',
                    textTransform: 'uppercase', letterSpacing: '0.6px', whiteSpace: 'nowrap',
                  }}>
                    ＋ Entrada de stock
                  </Typography>
                  <Box sx={{ flex: 1, height: '1px', background: '#E0E0E0' }} />
                </Box>

                {/* 입력 폼 — Cantidad/Limpiar/Guardar 인라인 액션 포함 (Row 3 내부) */}
                <Box sx={{ px: 2, pb: 2, display: 'flex', gap: 1.5, alignItems: 'stretch' }}>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <BasicDataCard
                      onSubmit={mode === 'edit' ? handleEdit : handleSubmit}
                      mode={mode}
                      cantidad={cantidad}
                      setCantidad={setCantidad}
                      useVariants={useVariants}
                      variantsTotal={variants.reduce(
                        (acc: number, row: any) => acc + row.stocks.reduce((a: number, s: any) => a + Number(s.stock), 0), 0
                      )}
                      loading={loading}
                      onReset={resetAll}
                      onStartNewProduct={handleStartNewProduct}
                    />
                  </Box>
                  {/* 선택/입력 제품 사진 — 우측 세로(높이 채움). 신규 업로드 미리보기 우선. */}
                  <Box sx={{ width: 132, flexShrink: 0, display: 'flex' }}>
                    <ProductPhotoBox
                      previewSrc={(product as any)?.imageFilePreviews?.[0]}
                      productId={(product as any)?.id ?? null}
                      fill
                    />
                  </Box>
                </Box>
              </Box>
            </Box>

            {/* ── 세로 리사이저 (좌우) ── */}
            <Box
              onMouseDown={onLRResizerMouseDown}
              sx={{
                flexShrink: 0,
                width: `${RESIZER_W}px`,
                cursor: 'ew-resize',
                background: '#F5F5F5',
                borderLeft: '1px solid #E0E0E0',
                borderRight: '1px solid #E0E0E0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                userSelect: 'none',
                zIndex: 10,
                transition: 'background .15s, border-color .15s',
                '&:hover': {
                  background: '#E0F7FA',
                  borderColor: '#00BCD4',
                  '& .resizer-handle span': { background: '#0097A7' },
                },
              }}
            >
              {/* 3개 세로선 핸들 */}
              <Box className="resizer-handle" sx={{ display: 'flex', flexDirection: 'column', gap: '3px', pointerEvents: 'none' }}>
                {[0,1,2].map(i => (
                  <Box
                    component="span"
                    key={i}
                    sx={{ width: 2, height: 28, borderRadius: 1, background: '#BDBDBD', transition: 'background .15s' }}
                  />
                ))}
              </Box>
            </Box>

            {/* ── 우측 패널 (상하 분할: VariantsStock ↔ Códigos madres) ── */}
            <Box
              ref={rightPanelRef}
              sx={{
                flex: 1,
                minWidth: MIN_RIGHT,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                gap: 1.5,
                p: 2,
              }}
            >
              {/* 상단 고정: SelectorBranch */}
              <Box sx={{ flexShrink: 0 }}>
                <SelectorBranch value={selectedBranches} onChange={setSelectedBranches} />
              </Box>

              {/* useVariants=false 매장은 VariantsStock / TB Resizer / editingMadre infoBar 렌더하지 않음 */}
              {useVariants && editingMadre && (
                <Box sx={{
                  flexShrink: 0, display: 'flex', alignItems: 'center', gap: 1,
                  px: 1.5, py: 0.8, background: '#F8FBFF', border: '1px solid #E3F2FD', borderRadius: 1,
                }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: 13, fontWeight: 700, color: '#1976D2' }}>
                      {editingMadre.parentName}
                    </Typography>
                    <Typography sx={{ fontSize: 10, fontFamily: 'monospace', color: '#9E9E9E' }}>
                      {editingMadre.parentSku} — editando variantes
                    </Typography>
                  </Box>
                  <Box sx={{ px: 1, py: 0.3, borderRadius: 1, background: '#FFF3E0', fontSize: 10, fontWeight: 700, color: '#E65100' }}>
                    EDITANDO
                  </Box>
                  <Button size="small" onClick={() => { handleMadreClick(null); resetAll(); }} sx={{ minWidth: 'auto', fontSize: 11, color: '#9E9E9E' }}>
                    ✕
                  </Button>
                </Box>
              )}

              {useVariants && (
                <>
                  {/* VariantsStock — 고정 높이(상하 resizer로 조절) */}
                  <Box
                    sx={{
                      height: variantsH,
                      minHeight: MIN_VARIANTS_H,
                      flexShrink: 0,
                      overflow: 'auto',
                      '&::-webkit-scrollbar': { width: 6 },
                      '&::-webkit-scrollbar-thumb': { bgcolor: 'rgba(0,0,0,.15)', borderRadius: 3 },
                      '&::-webkit-scrollbar-track': { bgcolor: 'transparent' },
                    }}
                  >
                    <VariantsStock />
                  </Box>

                  {/* ── 상하 리사이저 (Variantes ↔ Códigos madres) ── */}
                  <Box
                    onMouseDown={onTBResizerMouseDown}
                    sx={{
                      flexShrink: 0,
                      height: `${RESIZER_H}px`,
                      cursor: 'ns-resize',
                      background: '#F5F5F5',
                      borderTop: '1px solid #E0E0E0',
                      borderBottom: '1px solid #E0E0E0',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      userSelect: 'none',
                      transition: 'background .15s, border-color .15s',
                      '&:hover': {
                        background: '#E0F7FA',
                        borderColor: '#00BCD4',
                        '& .tb-resizer-handle span': { background: '#0097A7' },
                      },
                    }}
                  >
                    <Box className="tb-resizer-handle" sx={{ display: 'flex', flexDirection: 'row', gap: '3px', pointerEvents: 'none' }}>
                      {[0, 1, 2].map(i => (
                        <Box
                          component="span"
                          key={i}
                          sx={{ width: 28, height: 2, borderRadius: 1, background: '#BDBDBD', transition: 'background .15s' }}
                        />
                      ))}
                    </Box>
                  </Box>
                </>
              )}

              {/* ProductParentList — 남는 세로 공간을 항상 채움.
                  외부 overflow 제거 → 내부 ProductParentList 의 테이블 영역이 단일 스크롤 컨테이너 */}
              <Box
                sx={{
                  flex: 1,
                  minHeight: MIN_PARENT_H,
                  display: 'flex',
                  flexDirection: 'column',
                  overflow: 'hidden',
                }}
              >
                <ProductParentList refresh={refreshProducts} />
              </Box>
            </Box>
          </Box>

        </Box>
      </form>
      {/* ── 재입고 수정 확인 다이얼로그 ── */}
      <Dialog open={openEditConfirm} onClose={() => setOpenEditConfirm(false)} maxWidth="sm" fullWidth>
        <DialogTitle>¿Aplicar las correcciones?</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 1.5, color: '#616161' }}>
            Los valores se reemplazarán con el monto ABSOLUTO mostrado (no se suma).
          </Typography>

          {/* Stock 변경 섹션 */}
          {editDiffPreview.length > 0 && (
            <Box sx={{ border: '1px solid #E0E0E0', borderRadius: 1, p: 1, mb: 1 }}>
              <Typography sx={{ fontSize: 11, fontWeight: 700, color: '#0097A7', textTransform: 'uppercase', mb: 0.5 }}>
                Stock
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 80px 80px', fontSize: 11, fontWeight: 700, color: '#9E9E9E', pb: 0.5, borderBottom: '1px solid #EEEEEE', mb: 0.5 }}>
                <Box>Color</Box>
                <Box>Talle</Box>
                <Box sx={{ textAlign: 'right' }}>Antes</Box>
                <Box sx={{ textAlign: 'right' }}>Nuevo</Box>
              </Box>
              {editDiffPreview.map((d) => (
                <Box key={d.variantId} sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 80px 80px', fontSize: 13, py: 0.4 }}>
                  <Box>{d.colorLabel}</Box>
                  <Box>{d.sizeLabel}</Box>
                  <Box sx={{ textAlign: 'right', color: '#9E9E9E', textDecoration: 'line-through' }}>{d.oldStock}</Box>
                  <Box sx={{ textAlign: 'right', fontWeight: 700, color: d.newStock > d.oldStock ? '#2E7D32' : d.newStock < d.oldStock ? '#C62828' : '#616161' }}>
                    {d.newStock}
                  </Box>
                </Box>
              ))}
            </Box>
          )}

          {/* 가격 변경 섹션 */}
          {editPriceDiff.length > 0 && (
            <Box sx={{ border: '1px solid #E0E0E0', borderRadius: 1, p: 1, mb: 1 }}>
              <Typography sx={{ fontSize: 11, fontWeight: 700, color: '#0097A7', textTransform: 'uppercase', mb: 0.5 }}>
                Precios
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 110px 110px', fontSize: 11, fontWeight: 700, color: '#9E9E9E', pb: 0.5, borderBottom: '1px solid #EEEEEE', mb: 0.5 }}>
                <Box>Tipo</Box>
                <Box sx={{ textAlign: 'right' }}>Antes</Box>
                <Box sx={{ textAlign: 'right' }}>Nuevo</Box>
              </Box>
              {editPriceDiff.map((p) => (
                <Box key={p.priceTypeId} sx={{ display: 'grid', gridTemplateColumns: '1fr 110px 110px', fontSize: 13, py: 0.4 }}>
                  <Box>{p.label}</Box>
                  <Box sx={{ textAlign: 'right', color: '#9E9E9E', textDecoration: 'line-through' }}>${p.oldAmount.toLocaleString()}</Box>
                  <Box sx={{ textAlign: 'right', fontWeight: 700, color: p.newAmount > p.oldAmount ? '#2E7D32' : p.newAmount < p.oldAmount ? '#C62828' : '#616161' }}>
                    ${p.newAmount.toLocaleString()}
                  </Box>
                </Box>
              ))}
            </Box>
          )}

          <Typography variant="caption" sx={{ color: '#9E9E9E' }}>
            Fecha: {selectedDate}  ·  Stock: {editDiffPreview.length}  ·  Precios: {editPriceDiff.length}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenEditConfirm(false)} color="secondary">
            Cancelar
          </Button>
          <Button
            onClick={doEdit}
            color="primary"
            variant="contained"
            disabled={loading}
          >
            {loading ? <CircularProgress size={20} /> : "OK, corregir"}
          </Button>
        </DialogActions>
      </Dialog>

    </>
  );
};

export default ProductsView;
