import { Box } from "@mui/material";
import InventoryDialog from "./InventoryDialog";
import { useCallback, useEffect, useMemo, useState } from "react";
import apiConnector from "src/services/api.service";
import { COLUMNS_PARENT, columnsParentWithWeb } from "./DataConfig";
import { useAuth } from "src/hooks/useAuth";
import { useShopStatus } from "src/hooks/api/useShopStatus";
import FullTable from "src/components/table/FullTable";
import { defaultDataList, IDataList } from "src/types/apps/listTypes";

import { useProductContext } from "src/views/products/hook/ProductContext";
import CustomTextField from "src/@core/components/mui/text-field";
import toast from "react-hot-toast";

interface ProductParentListProps {
  refresh: boolean;
}

const ProductParentList = ({ refresh }: ProductParentListProps) => {
  const {
    setProduct,
    setVariants,
    setPrices,
    setSelectedSizes,
    selectedDate,
    setMode,
    setOriginalStocks,
    setOriginalPrices,
    setOriginalBasePrice,
  } = useProductContext();
  const [products, setProducts] = useState<IDataList>({...defaultDataList});
  const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 50 });
  const [rowSelected, setRowSelected] = useState<any[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [variantsToday, setVariantsToday] = useState<any[]>([]);
  const [dialogMode, setDialogMode] = useState<'none' | 'add' | 'edit'>("none");
  const [editStocks, setEditStocks] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const { user } = useAuth();

  // 공개몰(Tienda Web) 활성 매장에서만 Web 게시 컬럼 노출
  const { shopEnabled } = useShopStatus(user?.storeId);

  const getProducts = useCallback(async () => {
    const { page, pageSize } = paginationModel;
    const params: any = { page, pageSize };
    if (searchTerm) params.query = searchTerm;
    const result: any = await apiConnector.get('/products/by-parent?parent=false', params);
    setProducts(result);
  }, [setProducts, paginationModel, searchTerm]);

useEffect(() => {
    getProducts();
  }, [getProducts, refresh]);

  // 공개몰 게시 토글 — 낙관적 갱신 후 서버 반영, 실패 시 원복 (madre 행 Web 아이콘 클릭)
  const handleToggleWeb = useCallback(async (row: any, next: boolean) => {
    const applyLocal = (value: boolean) => {
      setProducts((prev: any) => ({
        ...prev,
        data: Array.isArray(prev?.data)
          ? prev.data.map((r: any) =>
              r.id === row.id ? { ...r, isPublishedShop: value } : r,
            )
          : prev?.data,
      }));
    };
    applyLocal(next);
    try {
      await apiConnector.put('/products/publish-shop', {
        productIds: [row.id],
        published: next,
      });
      toast.success(
        next ? 'Publicado en la tienda web' : 'Quitado de la tienda web',
      );
    } catch (err) {
      console.error('[TiendaWeb] publish-shop 실패:', err);
      applyLocal(!next);
      toast.error('No se pudo actualizar la tienda web');
    }
  }, [setProducts]);

  // 컬럼 참조 안정화 — shopEnabled 일 때만 Web 컬럼 포함 (DataGrid 재측정 최소화)
  const cols = useMemo(
    () => (shopEnabled ? columnsParentWithWeb(handleToggleWeb) : COLUMNS_PARENT),
    [shopEnabled, handleToggleWeb],
  );

  const handleRowSelection = async (selection: any) => {
    console.log('[PARENT-ROW-CLICK] handleRowSelection 진입', { selection });
    setRowSelected(selection);
    if (!selection || selection.length === 0) {
      console.warn('[PARENT-ROW-CLICK] selection 비어있음 → 중단');

      return;
    }
    const parentId = selection[0];
    if (!parentId) {
      console.warn('[PARENT-ROW-CLICK] parentId falsy → 중단', { parentId });

      return;
    }
    console.log('[PARENT-ROW-CLICK] parentId 결정', { parentId, selectedDate });

    const checkDate = selectedDate || (() => {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const dd = String(today.getDate()).padStart(2, '0');

      return `${yyyy}-${mm}-${dd}`;
    })();

    try {
      console.log(`[PARENT-ROW-CLICK] GET /products/${parentId}/inventory-by-date?date=${checkDate}`);

      // 부모의 모든 variant + 오늘 입고 정보 조회
      const res: any = await apiConnector.get(`/products/${parentId}/inventory-by-date`, { date: checkDate });
      const data = res?.data || res || {};
      const parent = data.parent || {};
      const apiVariants: any[] = Array.isArray(data.variants) ? data.variants : [];
      const todayHasEntries = Boolean(data.todayHasEntries);
      console.log('[PARENT-ROW-CLICK] inventory 응답', {
        parentId: parent.id,
        parentSku: parent.sku,
        variantsLen: apiVariants.length,
        todayHasEntries,
        sample: apiVariants.slice(0, 3).map(v => ({ vid: v?.id, c: v?.color?.id, s: v?.size?.id, stock: v?.stock })),
      });

      // ── 1) 메인 폼(BasicDataCard)을 부모 정보로 채움 ──
      // categories/subcategories/supplierId/seasonId/originId/sku/name/description 등
      setProduct({
        id: parent.id,
        parentId: parent.id, // 재입고 모드 식별용
        sku: parent.sku || '',
        name: parent.name || '',
        description: parent.description || '',
        imageUrl: parent.imageUrl,
        status: parent.status || 'active',
        categories: parent.categories || (parent.categoryId ? [parent.categoryId] : []),
        subcategories: parent.subcategories || [],
        supplierId: parent.supplierId,
        seasonId: parent.seasonId,
        originId: parent.originId,
        price: parent.price != null
          ? Number(parent.price)
          : (Array.isArray(parent.prices) && parent.prices.length > 0
              ? Number(parent.prices[0].amount) || 0
              : 0),

        // 공개몰(Tienda Web) 게시 여부 — 폼 토글 상태 반영
        isPublishedShop: parent.isPublishedShop ?? false,
      });
      setOriginalBasePrice(parent.price != null
        ? Number(parent.price)
        : (Array.isArray(parent.prices) && parent.prices.length > 0
            ? Number(parent.prices[0].amount) || 0
            : 0));

      // 가격: priceTypeId 기준으로 컨텍스트에 주입 + 원본 스냅샷 보관 (수정 비교용)
      if (Array.isArray(parent.prices) && parent.prices.length > 0) {
        const mappedPrices = parent.prices.map((p: any) => ({
          priceTypeId: p.priceTypeId || p.priceType?.id,
          amount: Number(p.amount) || 0,
          currency: p.currency || 'ARS',
        }));
        setPrices(mappedPrices);

        // 깊은 복사로 스냅샷 — 이후 사용자가 수정해도 원본은 그대로 유지
        setOriginalPrices(mappedPrices.map((p: any) => ({ ...p })));
      } else {
        setOriginalPrices([]);
      }

      // ── 2) 색/사이즈 격자 자동 구성 ──
      // variant 들에서 고유 색상, 고유 사이즈를 추출
      const sizeMap = new Map<number, any>();
      const colorMap = new Map<number, any>();
      for (const v of apiVariants) {
        const s = v.size;
        const c = v.color;
        if (s?.id && !sizeMap.has(s.id)) sizeMap.set(s.id, s);
        if (c?.id && !colorMap.has(c.id)) colorMap.set(c.id, c);
      }
      const uniqueSizes = Array.from(sizeMap.values());
      const uniqueColors = Array.from(colorMap.values());

      // selectedSizes 컬럼 설정 (variant 에 등장한 사이즈만)
      if (uniqueSizes.length > 0) {
        setSelectedSizes(uniqueSizes.map((s: any) => ({ id: s.id, name: s.name })));
      }

      // 색상별로 행을 만들고, 각 행은 사이즈별 stock 을 가짐
      // 오늘 입고된 stock 이 있으면 해당 값, 없으면 0
      const variantRows = uniqueColors.map((c: any) => {
        const stocks = uniqueSizes.map((s: any) => {
          const matched = apiVariants.find(
            (v: any) => v.color?.id === c.id && v.size?.id === s.id
          );

          return {
            sizeId: s.id,
            stock: matched ? Number(matched.stock || 0) : 0,
            id: matched?.id,
          };
        });

        return {
          colorId: c.id,
          stocks,
        };
      });

      setVariants(variantRows);

      // 원본 stock 스냅샷 (수정 모드 비교용)
      const originalStocksArr: any[] = [];
      for (const row of variantRows) {
        for (const st of row.stocks) {
          if (st.id) {
            originalStocksArr.push({
              id: st.id,
              colorId: row.colorId,
              sizeId: st.sizeId,
              stock: Number(st.stock),
            });
          }
        }
      }
      setOriginalStocks(originalStocksArr);

      // 오늘 입고가 이미 있는 경우는 수정 모드, 없으면 재입고(add) 모드로 동작
      setMode(todayHasEntries ? 'edit' : 'add');

      // 다이얼로그는 띄우지 않음 — 메인 폼에 그대로 채워짐
      setDialogMode('none');
      setDialogOpen(false);
      setVariantsToday([]);

      toast.success(
        todayHasEntries
          ? 'Variantes existentes cargadas (con entradas de hoy)'
          : 'Variantes cargadas con stock 0 — ingrese solo las cantidades nuevas'
      );
    } catch (err) {
      console.error("Error consultando variantes del día:", err);
      toast.error('No se pudieron cargar las variantes del producto');
    }
  };

  const setPagination = (model: any) => {
    setPaginationModel(model);
    getProducts();
  }

  return (
    <>


      <Box
        component="fieldset"
        sx={{
          border: '1px solid #E0E0E0',
          borderRadius: '6px',
          p: 1.5,
          pt: 0.5,
          m: 0,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',

          // 부모 컨테이너의 빈 세로 공간을 항상 채우도록 — minHeight: 0 은 flex 자식이 축소되도록 허용
          flex: 1,
          minHeight: 0,
          height: '100%',
        }}
      >
        <legend style={{ fontSize: 12, fontWeight: 700, color: '#616161', padding: '0 6px' }}>
          Códigos madres
        </legend>
        <CustomTextField
          placeholder="Buscar por SKU o nombre"
          variant="outlined"
          size="small"
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ mb: 1, flexShrink: 0 }}
          fullWidth
        />
        <Box sx={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
          <FullTable
            data={products}
            columns={cols}
            paginationModel={paginationModel}
            setPagination={setPagination}
            checkboxSelection={false}
            disableRowSelectionOnClick={false}
            rowSelected={rowSelected}
            setRowSelected={handleRowSelection}
            fillHeight
            rowHeight={28}
            headerHeight={32}
            onRowClick={(params: any) => {
              // AG Grid 는 row id 를 params.row.id 에 넣고 params.id 는 undefined 로 옴.
              // → params.id 사용하면 [undefined] 가 selection 으로 전달돼 handleRowSelection 가드에 막혀 silent fail.
              const rowId = params?.row?.id ?? params?.id;
              console.log('[PARENT-ROW-CLICK] onRowClick fired', {
                paramsId: params?.id,
                paramsRowId: params?.row?.id,
                resolvedRowId: rowId,
                paramsRowSku: params?.row?.sku,
                paramsRowName: params?.row?.name,
              });
              if (rowId == null) {
                console.warn('[PARENT-ROW-CLICK] row id 결정 실패 → 중단');

                return;
              }
              handleRowSelection([rowId]);
            }}
            storageKey="products.codigosMadres"
          />
        </Box>
      </Box>
      <InventoryDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        variantsToday={variantsToday}
        dialogMode={dialogMode}
        setDialogMode={setDialogMode}
        editStocks={editStocks}
        setEditStocks={setEditStocks}
      />
    </>
  );
};

export default ProductParentList;
